--
-- PostgreSQL database dump
--

\restrict IXf93zBuPPiuzBRkvaKgNczev2ZEdZ8Q9xfzvIg5AqD8D0w7yniW2Sa23LaG6g5

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX IF EXISTS public.videos_status_idx;
DROP INDEX IF EXISTS public.stories_status_idx;
DROP INDEX IF EXISTS public.meta_ad_insights_uniq;
DROP INDEX IF EXISTS public.events_status_idx;
DROP INDEX IF EXISTS public.ad_perf_uniq;
ALTER TABLE IF EXISTS ONLY public.videos DROP CONSTRAINT IF EXISTS videos_pkey;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS stories_pkey;
ALTER TABLE IF EXISTS ONLY public.rotation_rules DROP CONSTRAINT IF EXISTS rotation_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.meta_campaign_budgets DROP CONSTRAINT IF EXISTS meta_campaign_budgets_pkey;
ALTER TABLE IF EXISTS ONLY public.meta_ad_insights DROP CONSTRAINT IF EXISTS meta_ad_insights_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.crawl_sources DROP CONSTRAINT IF EXISTS crawl_sources_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_sources DROP CONSTRAINT IF EXISTS blog_sources_pkey;
ALTER TABLE IF EXISTS ONLY public.blog_sources DROP CONSTRAINT IF EXISTS blog_sources_blog_id_unique;
ALTER TABLE IF EXISTS ONLY public.auth_config DROP CONSTRAINT IF EXISTS auth_config_pkey;
ALTER TABLE IF EXISTS ONLY public.ads DROP CONSTRAINT IF EXISTS ads_pkey;
ALTER TABLE IF EXISTS ONLY public.ad_products DROP CONSTRAINT IF EXISTS ad_products_pkey;
ALTER TABLE IF EXISTS ONLY public.ad_pools DROP CONSTRAINT IF EXISTS ad_pools_pkey;
ALTER TABLE IF EXISTS ONLY public.ad_performances DROP CONSTRAINT IF EXISTS ad_performances_pkey;
ALTER TABLE IF EXISTS ONLY public.ad_payments DROP CONSTRAINT IF EXISTS ad_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.ad_payments DROP CONSTRAINT IF EXISTS ad_payments_order_id_unique;
ALTER TABLE IF EXISTS ONLY public.ad_alerts DROP CONSTRAINT IF EXISTS ad_alerts_pkey;
ALTER TABLE IF EXISTS ONLY drizzle.__drizzle_migrations DROP CONSTRAINT IF EXISTS __drizzle_migrations_pkey;
ALTER TABLE IF EXISTS drizzle.__drizzle_migrations ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.videos;
DROP TABLE IF EXISTS public.stories;
DROP TABLE IF EXISTS public.rotation_rules;
DROP TABLE IF EXISTS public.meta_campaign_budgets;
DROP TABLE IF EXISTS public.meta_ad_insights;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.crawl_sources;
DROP TABLE IF EXISTS public.blog_sources;
DROP TABLE IF EXISTS public.auth_config;
DROP TABLE IF EXISTS public.ads;
DROP TABLE IF EXISTS public.ad_products;
DROP TABLE IF EXISTS public.ad_pools;
DROP TABLE IF EXISTS public.ad_performances;
DROP TABLE IF EXISTS public.ad_payments;
DROP TABLE IF EXISTS public.ad_alerts;
DROP SEQUENCE IF EXISTS drizzle.__drizzle_migrations_id_seq;
DROP TABLE IF EXISTS drizzle.__drizzle_migrations;
DROP SCHEMA IF EXISTS drizzle;
--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: ad_alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_alerts (
    id text NOT NULL,
    type text DEFAULT 'info'::text NOT NULL,
    level text DEFAULT 'info'::text NOT NULL,
    message text DEFAULT ''::text NOT NULL,
    ad_id text,
    pool_id text,
    resolved integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ad_alerts OWNER TO postgres;

--
-- Name: ad_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_payments (
    id text NOT NULL,
    order_id text NOT NULL,
    payment_key text,
    ad_id text,
    plan text DEFAULT ''::text NOT NULL,
    amount integer NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    method text,
    receipt_url text,
    customer_name text DEFAULT ''::text NOT NULL,
    customer_email text DEFAULT ''::text NOT NULL,
    raw_response jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    paid_at timestamp without time zone,
    product_id text,
    product_name_snapshot text,
    product_price_snapshot integer,
    margin_rate_snapshot real,
    ad_duration_days_snapshot integer,
    product_type_snapshot text
);


ALTER TABLE public.ad_payments OWNER TO postgres;

--
-- Name: ad_performances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_performances (
    id text NOT NULL,
    ad_id text NOT NULL,
    pool_id text,
    date text DEFAULT ''::text NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    spend integer DEFAULT 0 NOT NULL,
    reach integer DEFAULT 0 NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    ctr real,
    cpc integer
);


ALTER TABLE public.ad_performances OWNER TO postgres;

--
-- Name: ad_pools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_pools (
    id text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    objective text DEFAULT 'awareness'::text NOT NULL,
    ad_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    total_budget integer DEFAULT 0 NOT NULL,
    start_date text DEFAULT ''::text NOT NULL,
    end_date text DEFAULT ''::text NOT NULL,
    ai_mode text DEFAULT 'equal'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    meta_campaign_id text,
    meta_ad_set_id text,
    meta_synced_at timestamp without time zone,
    meta_sync_status text,
    rotation_mode text DEFAULT 'equal'::text NOT NULL,
    ad_dates jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.ad_pools OWNER TO postgres;

--
-- Name: ad_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_products (
    id text NOT NULL,
    name text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    amount integer NOT NULL,
    ad_duration_days integer,
    product_type text DEFAULT 'etc'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    margin_rate real DEFAULT 0.3 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ad_products OWNER TO postgres;

--
-- Name: ads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ads (
    id text NOT NULL,
    business_name text DEFAULT ''::text NOT NULL,
    contact_name text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    category text DEFAULT '기타'::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    url text DEFAULT ''::text NOT NULL,
    image_url text,
    extra_images jsonb,
    plan text DEFAULT 'basic'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    is_free_ad boolean DEFAULT true NOT NULL,
    social_draft jsonb,
    ai_score integer,
    ai_note text,
    meta_ad_id text,
    report_token text,
    meta_creative_id text,
    meta_image_hash text,
    meta_status text,
    report_sent_at timestamp without time zone,
    is_premium_featured boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ads OWNER TO postgres;

--
-- Name: auth_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_config (
    id text DEFAULT 'main'::text NOT NULL,
    password_hash text NOT NULL,
    salt text NOT NULL
);


ALTER TABLE public.auth_config OWNER TO postgres;

--
-- Name: blog_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blog_sources (
    id text NOT NULL,
    name text NOT NULL,
    blog_id text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.blog_sources OWNER TO postgres;

--
-- Name: crawl_sources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crawl_sources (
    id text NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.crawl_sources OWNER TO postgres;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    date text DEFAULT ''::text NOT NULL,
    start_date text DEFAULT ''::text NOT NULL,
    end_date text DEFAULT ''::text NOT NULL,
    schedule_status text DEFAULT 'upcoming'::text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    category text DEFAULT '지역소식'::text NOT NULL,
    thumbnail text,
    video_url text,
    link text DEFAULT ''::text NOT NULL,
    source text DEFAULT ''::text NOT NULL,
    contact text DEFAULT ''::text NOT NULL,
    source_type text DEFAULT 'html'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    social_draft jsonb,
    crawled_at text DEFAULT ''::text NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    extra_images jsonb,
    hashtags jsonb
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: meta_ad_insights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meta_ad_insights (
    id text NOT NULL,
    ad_id text NOT NULL,
    ad_name text DEFAULT ''::text NOT NULL,
    ad_set_id text,
    ad_set_name text,
    campaign_id text,
    campaign_name text,
    date_start text NOT NULL,
    date_stop text NOT NULL,
    impressions integer DEFAULT 0 NOT NULL,
    clicks integer DEFAULT 0 NOT NULL,
    spend real DEFAULT 0 NOT NULL,
    reach integer DEFAULT 0 NOT NULL,
    frequency real,
    ctr real,
    cpc real,
    cpp real,
    status text,
    health_status text DEFAULT 'ok'::text NOT NULL,
    health_issues jsonb DEFAULT '[]'::jsonb NOT NULL,
    collected_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meta_ad_insights OWNER TO postgres;

--
-- Name: meta_campaign_budgets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meta_campaign_budgets (
    campaign_id text NOT NULL,
    campaign_name text DEFAULT ''::text NOT NULL,
    daily_limit integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.meta_campaign_budgets OWNER TO postgres;

--
-- Name: rotation_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rotation_rules (
    id text NOT NULL,
    pool_id text NOT NULL,
    ad_id text NOT NULL,
    hour_slot integer DEFAULT 0 NOT NULL,
    weight real DEFAULT 1 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    ai_reason text
);


ALTER TABLE public.rotation_rules OWNER TO postgres;

--
-- Name: stories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stories (
    id text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    images jsonb DEFAULT '[]'::jsonb NOT NULL,
    source_url text DEFAULT ''::text NOT NULL,
    author text DEFAULT ''::text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stories OWNER TO postgres;

--
-- Name: videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.videos (
    id text NOT NULL,
    youtube_id text DEFAULT ''::text NOT NULL,
    title text DEFAULT ''::text NOT NULL,
    channel_name text DEFAULT ''::text NOT NULL,
    thumbnail_url text,
    description text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    embeddable boolean,
    view_count integer,
    social_caption text
);


ALTER TABLE public.videos OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
\.


--
-- Data for Name: ad_alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_alerts (id, type, level, message, ad_id, pool_id, resolved, created_at) FROM stdin;
\.


--
-- Data for Name: ad_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_payments (id, order_id, payment_key, ad_id, plan, amount, status, method, receipt_url, customer_name, customer_email, raw_response, created_at, paid_at, product_id, product_name_snapshot, product_price_snapshot, margin_rate_snapshot, ad_duration_days_snapshot, product_type_snapshot) FROM stdin;
fabb687a27e34a82963496fd53b1dda7	PLAY-36F1B35EF47C57F0	\N	\N	basic	99000	pending	\N	\N	테스트	test@play.com	\N	2026-05-21 10:53:06.721404	\N	\N	\N	\N	\N	\N	\N
4c049b0ba6c041a0bc590cd92773b774	PLAY-7ED2C0112DB5456D	\N	\N	3일 광고	40000	pending	\N	\N	테스트광고주	test@play.com	\N	2026-05-21 11:14:06.587835	\N	0c3c02c86b8f4528a5e42b22	3일 광고	40000	0.3	3	ad_run
\.


--
-- Data for Name: ad_performances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_performances (id, ad_id, pool_id, date, impressions, clicks, spend, reach, source, created_at, ctr, cpc) FROM stdin;
\.


--
-- Data for Name: ad_pools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_pools (id, name, objective, ad_ids, total_budget, start_date, end_date, ai_mode, status, created_at, updated_at, meta_campaign_id, meta_ad_set_id, meta_synced_at, meta_sync_status, rotation_mode, ad_dates) FROM stdin;
b2968b7b-fc75-486a-b342-953f58d15dff	테스트묶음	awareness	[]	100000	2026-05-01	2026-06-30	overexposure_prevention	draft	2026-05-21 08:51:37.96789	2026-05-21 08:51:37.96789	\N	\N	\N	\N	equal	{}
ea6531fa-d0a0-4d7f-b87c-75dbd0f53ae2	테스트풀	awareness	[]	100000	2026-05-21	2026-05-28	equal	draft	2026-05-21 09:00:41.040792	2026-05-21 09:00:41.040792	\N	\N	\N	\N	equal	{}
\.


--
-- Data for Name: ad_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_products (id, name, description, amount, ad_duration_days, product_type, is_active, sort_order, margin_rate, created_at, updated_at) FROM stdin;
eeef8975398c4f49a266abc6	1일 광고	SNS 피드 1일 집행	15000	1	ad_run	t	1	0.3	2026-05-21 11:13:38.835	2026-05-21 11:13:38.835
0c3c02c86b8f4528a5e42b22	3일 광고	SNS 피드 3일 집행	40000	3	ad_run	t	2	0.3	2026-05-21 11:13:39.054	2026-05-21 11:13:39.054
72ee066652c84d31afdffb22	5일 광고	SNS 피드 5일 집행	60000	5	ad_run	t	3	0.3	2026-05-21 11:13:39.282	2026-05-21 11:13:39.282
6bef76da50d840b69cae351c	7일 광고	SNS 피드 7일 집행	80000	7	ad_run	t	4	0.3	2026-05-21 11:13:39.497	2026-05-21 11:13:39.497
5f6a897658b84315ae5e6c35	이미지 제작 5컷	SNS용 이미지 5컷 제작	100000	\N	image_create	t	5	0.3	2026-05-21 11:13:39.711	2026-05-21 11:13:39.711
8a7366e0a81042cf9680f4c7	취재 + 이미지 제작	현장 취재 및 SNS 콘텐츠 제작	200000	\N	coverage	t	6	0.3	2026-05-21 11:13:39.926	2026-05-21 11:13:39.926
\.


--
-- Data for Name: ads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ads (id, business_name, contact_name, phone, email, category, title, description, date, location, url, image_url, extra_images, plan, status, approved_at, created_at, is_free_ad, social_draft, ai_score, ai_note, meta_ad_id, report_token, meta_creative_id, meta_image_hash, meta_status, report_sent_at, is_premium_featured) FROM stdin;
\.


--
-- Data for Name: auth_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_config (id, password_hash, salt) FROM stdin;
main	b5d84ee6f1f61592f8122b757a1f72880a8d2cc39198a8f5aede98736c021726870442a5947d19a84165dcfcd15b3872182f095be7bc7062fddcb974a857d88e	4cbd01988895e556e8cb808eb7f66569
\.


--
-- Data for Name: blog_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blog_sources (id, name, blog_id, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: crawl_sources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crawl_sources (id, name, url, enabled, created_at) FROM stdin;
gn_yeyak	강릉시 이달의 행사	https://www.gn.go.kr/yeyak/selectUnityEventWebList.do?key=6420	t	2026-05-09 00:00:00
gn_artscenter	강릉아트센터	https://www.gn.go.kr/artscenter/selectMoonhwainList.do?key=5728&searchMoon_p_team=artCenter	t	2026-05-09 00:00:00
gncaf	강릉문화예술재단	https://www.gncaf.or.kr/ko/community/event	t	2026-05-09 00:00:00
9a42b8e6c3d359503a479d3250dda15a	강릉시청 공연/행사	https://www.gn.go.kr/yeyak/selectMoonhwainList.do?key=6422	t	2026-05-11 04:32:53.8
8413d48f68679f722eab58fdcb30a3be	교육/강좌	https://www.gn.go.kr/yeyak/selectUnityProgrmWebList.do?key=5411&insttTy=URINTY01	t	2026-05-11 04:34:08.435
524b0fccab03db8d4b7995f1e20117fa	체험/견학	https://www.gn.go.kr/yeyak/selectUnityExprnWebList.do?key=5532	t	2026-05-11 04:35:33.973
ecb2b83a9b991614f90adab5720c8833	지원/접수	https://www.gn.go.kr/yeyak/selectUserOnlineReceptionList.do?key=5540	t	2026-05-11 04:36:23.636
7d5086e6b2186994dca3c80b58a00c72	관광개발공사 행사안내	https://www.gtdc.or.kr/pub/bbsevent.do	t	2026-05-11 04:46:19.328
935f6b9c823bb08808bae2d4c67dbb10	강릉시립미술관	https://www.gn.go.kr/mu/selectMoonhwainList.do?key=6620&searchMoon_p_team=gnmu	t	2026-05-11 05:20:01.024
513809de7c582cd13b472e5c0beee376	강원일보-강릉	https://kwnews.co.kr/area/gangneung?area=W100000800003	t	2026-05-11 21:14:40.105
74ce0078cc9b3362c4f7750d5fb7ea9d	강원도민일보-강릉	https://cdn.kado.net/rss/gn_rss_allArticle.xml	t	2026-05-11 21:15:49.488
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, title, description, date, start_date, end_date, schedule_status, location, category, thumbnail, video_url, link, source, contact, source_type, status, social_draft, crawled_at, updated_at, extra_images, hashtags) FROM stdin;
78bd2d1a1165f3875594ee23fd8a0b4d	리쥬란, 대만 팝업스토어 8000명 방문…현지 시장 확대 가능성 확인	강릉에 본사를 둔 재생의학 전문기업 파마리서치가 대만 타이베이에서 운영한 리쥬란 팝업스토어를 통해 현지 시장 확대 가능성을 확인했다.파마리서치는 1~15일 대만 타이베이 중산역 인근 핵심 상권에서 ‘리쥬란 브랜드 스토리 팝업스토어’를 운영한 결과 방문맥이 8000여명에 달한다고 24일 밝혔다. 이번 팝업스토어는 대만 2030 소비자를 중심으로 리쥬란 브랜드를 알리기 위해 마련됐다. 팝업스토어가 열린 중산역 일대는 백화점과 쇼핑몰, 지하철역이 인접한 타이베이 대표 쇼핑 지역이다. 특히 패션과 뷰티 트렌드에 관심이 높은 젊은층 유동인구				dateUnknown	강릉	지역소식	https://cdn.kado.net/news/photo/202605/2051826_857964_1410.jpg	\N	https://www.kado.net/news/articleView.html?idxno=2051826	강원도민일보-강릉		rss	approved	\N	2026-05-24T06:11:20.868Z	2026-05-24 06:11:38.715692	\N	\N
3b4a107f077b0c1302bb8aa96de90c0d	2026년 소상공인 카드수수료 지원 신청	소상공인과 | 접수마감	2026-03-09	2026-03-09	2026-11-30	ongoing	소상공인과	지역소식	\N	\N	https://www.gn.go.kr/yeyak/selectUserOnlineReceptionView.do?key=5540&programKey=25	지원/접수		html	approved	\N	2026-05-24T06:09:33.949Z	2026-05-24 06:11:38.715692	\N	\N
843967ce50b84cc3abf0deeb1193a7b7	[6.3지선]김동기 강릉시장 후보(무) “무료 영화제 흑자 발언은 시민 기만”…김홍규 후보에 사과 촉구	무소속 김동기 강릉시장 후보는 국민의힘 김홍규 후보가 TV토론에서 정동진독립영화제 관련 ‘흑자’ 발언을 한 것과 관련해 “천박한 기만 발언을 즉각 철회하고 강릉 시민에게 사죄해야 한다”고 강하게 비...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250026000000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250025900000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.038Z	2026-05-24 06:11:38.715692	\N	\N
092fe943cd46c03ee0b68006a49cbac3	[6.3지선]강릉지역 대학교수 51인, 김홍규 강릉시장 후보 지지 선언	강릉지역 대학교수 51인이 국민의힘 김홍규 강릉시장 후보 지지를 공식 선언하고 지역 발전을 위한 정책 지원에 나섰다.\n강릉지역 교수들은 최근 김홍규 후보 선거사무소에서 기자회견을 열고 김 후보 지...				dateUnknown	강릉	지역소식	https://www.kwnews.co.kr/photos/2026/05/22/2026052250023900000_l.png	\N	https://kwnews.co.kr/page/view/2026052250025600000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.038Z	2026-05-24 06:11:38.715692	\N	\N
a10b6107d6cdfd22400bbb6b88ed0961	강릉시립노인요양센터, 가정의 달 맞아 문화공연 개최	강릉시립노인요양센터(시설장:황영범)는 5월 가정의 달을 맞아 지난 19일 오후 센터 1층 생활관에서 지역 재능기부 공연단체 ‘오음회’와 함께 문화공연을 개최했다.\n이번 공연은 오음회(회장:홍명표)의 재능기부...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250021500000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250021700000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.038Z	2026-05-24 06:11:38.715692	\N	\N
8b3864809fb1085a339743444412b16c	주문진읍 지역사회보장협의체, 독거노인 가구 도배 교체 지원	주문진읍 지역사회보장협의체(위원장:조태란·이정희)는 22일 주거 환경이 열악한 독거노인 가구를 대상으로 도배 교체 지원사업을 추진했다.\n이번 사업은 노후화된 벽지와 열악한 실내 환경으로 생활에 불편을 겪...				dateUnknown	강릉	지역소식	https://www.kwnews.co.kr/photos/2026/05/22/2026052250022200000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250022500000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-24 06:11:38.715692	\N	\N
dbaa5d540e504ffbaf2fb07d4861d31f	동부지방산림청, 국제 생물다양성의 날 맞아 무릉계곡 캠페인	동부지방산림청(청장:최수천)은 ‘국제 생물다양성의 날’을 맞아 22일 동해시 무릉계곡과 두타산 일원에서 등산객을 대상으로 생물다양성 보전의 중요성을 알리는 캠페인을 펼쳤다.\n이번 캠페인은 기후변화와 생물...				dateUnknown	강릉	핫플	https://www.kwnews.co.kr/photos/2026/05/22/2026052250022600000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250022800000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-24 06:11:38.715692	\N	\N
3b011577a725b9dd4c3b2a57903ad5c5	클릭테스트 이벤트	프리미엄 카드 클릭 테스트용				dateUnknown	강릉	행사	\N	\N	https://www.gangneung.go.kr	PLAY강릉		manual	approved	\N	2026-05-28T05:57:38.776Z	2026-05-28 05:57:38.778831	\N	\N
cfed20c9d1017e92843fccd38525b331	2026 문중자료특별전	百世淸風 백세에 귀감이 될 맑은 기풍–안동권씨 청풍당	2026-05-11	2026-05-11	2026-05-31	ongoing	(재)율곡 국학진흥원 별관	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=895&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-660-2018	html	draft	\N	2026-05-25T00:00:18.326Z	2026-05-25 00:00:18.347988	\N	\N
e493ef07cf95f83ca2a01122413475a1	2026 빵터지는 강릉 빵 페스타	시간 : 11:00 ~ 20:00	2026-05-22	2026-05-22	2026-05-25	ongoing	강릉 대도호부관아 일원	행사	https://www.gn.go.kr/DATA/event/main/P_D160BD22-237F-447D-6F73-4C6391CDCF7B.jpg	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=923&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사		html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
6e9502d80ff9605ff786c45de5d7e88b	클라라 주미 강 & 김선욱 듀오 리사이틀	시간 : 19:30	2026-05-26	2026-05-26	2026-05-26	tomorrow	강릉아트센터 사임당홀	행사	https://www.gn.go.kr/DATA/event/main/P_F47ABAA0-DDE0-21B8-3D95-D55F89B0A3AF.jpg	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=908&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사		html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
fd4a02cb480fe0c8eb8750070a42c698	시간의 흐름	지역예술가 권용자(개인) 회화 작품 전시	2026-05-27	2026-05-27	2026-06-07	upcoming	강릉시립미술관 교동	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=909&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
f38db96c0ff2ef15f3c3b13dc4db2ef0	뮤지엄 아카데미	김상욱 교수의 <물리학의 눈으로 본 미술> 주제 강연	2026-05-28	2026-05-28	2026-05-28	upcoming	강릉시립미술관 솔올	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=910&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
4642bb5424502db19194f0cadf9d9c19	TWO WAVES in 강릉Ⅱ	한‧일 발레 교류 프로젝트(국립발레단, 도쿄시티발레단 출연)	2026-05-29	2026-05-29	2026-05-30	upcoming	강릉아트센터 사임당홀	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=911&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-660-6800	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
0b08ffbed998deb62eeb2eaa63af9307	김동명 문학관 프로그램 백일장	시간 : 13:00	2026-05-30	2026-05-30	2026-05-30	upcoming	김동명문학관	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=912&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사		html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
149fd4f5cac0aec0de2c124cdb5b3a62	전시연계 교육 사색의 운동회 -좋았어 장애물	작가와 함께 전시관람 및 신체감상 체험	2026-05-30	2026-05-30	2026-05-30	upcoming	강릉시립미술관 교동	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=922&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
26dc6443dd61fcfe732148d7eaecf42f	전시연계 교육 행복한 우리집	가족과 함께 전시감상 및 팝업북 만들기 체험	2026-05-30	2026-05-30	2026-05-30	upcoming	강릉시립미술관 솔올	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=918&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
796f29f089c724e59f995f810555991c	「2026 강릉단오제」 대관령국사성황제· 산신제,구산·학산 서낭제, 봉안제	시간 : 10:00 ~ 19:00	2026-05-31	2026-05-31	2026-05-31	upcoming	대산령산신당·성황사, 구산·학산, 여성황사	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=913&searchYear=2026&searchMonth=05&searchEventCd=	강릉시 이달의 행사		html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
879d9304cf850baa0057348b477e9693	시간의 흐름	지역예술가 권용자(개인) 회화 작품 전시	2026-05-27	2026-05-27	2026-06-07	upcoming	강릉시립미술관 교동	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=909&searchYear=2026&searchMonth=06&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-24 06:11:38.715692	\N	\N
7c3bbe73244adb0bddbcb805580e5e01	사색의 운동회 _장애물을 긍정하며	한광우 작가의 오브제 조각, 드로잉 등 총 30여점 전시	2026-04-29	2026-04-29	2026-06-10	ongoing	강릉시립미술관 교동	행사	https://www.gn.go.kr/DATA/event/main/P_7025CBE8-55A8-C1A5-85F0-C74D3C2603C0.jpg	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=884&searchYear=2026&searchMonth=06&searchEventCd=	강릉시 이달의 행사	033-640-4271	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-25 00:00:18.347988	\N	\N
5f346b0f62444c569832c74a111a081a	장욱진의 대화: 서로가 된 풍경	장욱진 작가의 회화, 도자화, 먹그림 등 170여점 전시	2026-04-01	2026-04-01	2026-07-05	ongoing	강릉시립미술관 솔올	행사	\N	\N	https://www.gn.go.kr/yeyak/unityEventWebView.do?key=6420&eventNo=866&searchYear=2026&searchMonth=07&searchEventCd=	강릉시 이달의 행사	033-660-2018	html	draft	\N	2026-05-25T00:00:18.327Z	2026-05-24 06:11:38.715692	\N	\N
ce95a0b2f293886125d47928ee7b0f2f	[2기] 토요예술시식단	매주 토요일 ｜ 14:00 ~ 16:30 | 총6회차 | 강릉아트센터 예술교육실 | 예매마감	2026-05-23	2026-05-23	2026-06-20	ongoing	강릉아트센터 예술교육실	행사	https://gn.moonhwain.net:451/upload/pfm/202604/1361_copy_0.jpg	\N	https://www.gn.go.kr/artscenter/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=5728&searchYear=2026&searchMonth=05&searchMoon_p_team=artCenter&searchSiteId=artscenter&searchMoon_p_idx=1361	강릉아트센터		html	draft	\N	2026-05-25T00:00:08.335Z	2026-05-24 06:11:38.715692	\N	\N
913cf6c7686baf4dbd4fe72323bfb4e4	국립발레단X도쿄시티발레단_Two Waves in 강릉	29일(금) 19:30 | 30일(토) 14:00 | 100분(인터미션 20분 포함) | 강릉아트센터 사임당홀 | 예매가능	2026-05-29	2026-05-29	2026-05-30	upcoming	강릉아트센터 사임당홀	행사	https://gn.moonhwain.net:451/upload/pfm/202604/pImg1365_1.jpg	\N	https://www.gn.go.kr/artscenter/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=5728&searchYear=2026&searchMonth=05&searchMoon_p_team=artCenter&searchSiteId=artscenter&searchMoon_p_idx=1365	강릉아트센터	033-660-6800	html	draft	\N	2026-05-25T00:00:08.335Z	2026-05-25 00:00:18.347988	\N	\N
05f7a5672c1ef2ac21ee896c2dded815	클라라 주미 강 ＆ 김선욱 듀오 콘서트	오후 7시 30분 | 120분(인터미션 15분 포함) | 강릉아트센터 사임당홀 | 예매가능	2026-05-26	2026-05-26		tomorrow	강릉아트센터 사임당홀	행사	https://gn.moonhwain.net:451/upload/pfm/202602/pImg1343_1.jpg	\N	https://www.gn.go.kr/artscenter/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=5728&searchYear=2026&searchMonth=05&searchMoon_p_team=artCenter&searchSiteId=artscenter&searchMoon_p_idx=1343	강릉아트센터	033-660-6800	html	draft	\N	2026-05-25T00:00:08.335Z	2026-05-25 00:00:18.347988	\N	\N
20cae3b8c77723674916801d4ebdc5ea	존재의 시간	존재의 시간 기간2026.05.13 ~ 2026.05.27 시간19:00 장소스테이지무늬 가격정보전석 만원 문의010-9554-8022 예매링크https://booking.naver.com/booking/12/bizes/1455250 - 예매링크 목록으로	2026-05-13	2026-05-13	2026-05-27	ongoing	송대령	행사	https://www.gncaf.or.kr/upload/menu.asp?id=112&type=2&code=t	\N	https://www.gncaf.or.kr/ko/community/event?a=view&id=56&searchType=2026&keyword=5	강릉문화예술재단	010-9554-8022	html	draft	\N	2026-05-25T00:00:05.863Z	2026-05-24 06:11:38.715692	\N	\N
d0a6cd4303077eac2eb0f216ffb008d8	2026 관동산수 초대전 <삐끗>	2026 관동산수 초대전 <삐끗> 기간2026.05.21 ~ 2026.05.31 시간13:00~18:00 장소관동산수 Gallery 가격정보매주수요일 휴무 문의???? 【전시 개요】 ● 전시명: 김석기 네 번째 개인전 ‘삐끗(Oops!)’ ● 전시 기간: 2026년 5월 21일(목) ~ 5월 31일(일) ● 관람 시간: 13:00 ~ 18:00 (매주 수요일 휴관) ● 전시 장소: 관동산수 Gallery (강릉시 중앙시장길 20, 3층) ● 주최·주관: ㈜관동산수 【연계 프로그램】 ● 프로그램명: 삐끗 이후의 식탁 – 작가와의 대화 ● 일시: 2026년 5월 30일(토) 14:00 ~ 18:00 라이브 드로잉 18:00 ~ 20:00 포틀럭 및 작가와의 대화 ● 내용: 라이브 드로잉 관람 및 작가와의 교류 프로그램 ● 참여: 사전 예약 / 소규모 운영 (참가비 5,000원, 와인 제공) 목록으로	2026-05-21	2026-05-21	2026-05-31	ongoing	(주)관동산수	행사	https://www.gncaf.or.kr/upload/menu.asp?id=113&type=2&code=t	\N	https://www.gncaf.or.kr/ko/community/event?a=view&id=57&searchType=2026&keyword=5	강릉문화예술재단	033-647-6800	html	draft	\N	2026-05-25T00:00:05.863Z	2026-05-25 00:00:18.347988	\N	\N
50b10934cc24a2490afe463e63dbbeae	「2026 빵 터지는 강릉 빵 페스타」 개최 안내	「2026 빵 터지는 강릉 빵 페스타」 개최 안내 기간2026.05.22 ~ 2026.05.25 시간11:00 ~ 20:00 장소강릉 대도호부관아 일원 가격정보일부 유료 문의033-640-5582 강릉의 빵과 디저트 문화를 주제로 「2026 빵 터지는 강릉 빵 페스타」 가다음과 같이 개최되오니 많은 관심과 참여 부탁드립니다.□ 행사개요○ 행 사 명: 2026 빵 터지는 강릉 빵 페스타○ 행사일시: `26.5.22.(금) ~ 5.25.(월) (4일) 11:00 ~ 20:00○ 개최장소: 강릉 대도호부관아 일원○ 주요행사- 메인프로그램: 빵 터지는 베이킹쇼, 빵 터지는 마켓- 참여체험프로그램: 빵 터지는 베이킹클래스, 빵터지는 과자 꼴라쥬, 빵 터지는 박터트리기, 빵 터지는 운동회, 빵 보물 찾기- 부대프로그램: 빵 터지는 버스킹공연- 참여이벤트: 빵 터지는 영수증 이벤트, 빵 터지는 경품추첨 목록으로	2026-05-22	2026-05-22	2026-05-25	ongoing	문화산업팀	행사	https://www.gncaf.or.kr/upload/menu.asp?id=114&type=2&code=t	\N	https://www.gncaf.or.kr/ko/community/event?a=view&id=58&searchType=2026&keyword=5	강릉문화예술재단	033-640-5582	html	draft	\N	2026-05-25T00:00:05.863Z	2026-05-25 00:00:18.347988	\N	\N
a627d75a0254d2b8ea47b04bbc73ca58	[2기] 토요예술시식단	매주 토요일 ｜ 14:00 ~ 16:30 | 총6회차 | 강릉아트센터 예술교육실 | 예매마감	2026-05-23	2026-05-23	2026-06-20	ongoing	강릉아트센터 예술교육실	행사	https://gn.moonhwain.net:451/upload/pfm/202604/1361_copy_0.jpg	\N	https://www.gn.go.kr/yeyak/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=6422&searchYear=2026&searchMonth=05&searchSiteId=yeyak&searchMoon_p_idx=1361	강릉시청 공연/행사	033-660-2457	html	draft	\N	2026-05-25T00:00:08.011Z	2026-05-25 00:00:18.347988	\N	\N
649b094f995a1153ddd4c264229ce483	국립발레단X도쿄시티발레단_Two Waves in 강릉	29일(금) 19:30 | 30일(토) 14:00 | 100분(인터미션 20분 포함) | 강릉아트센터 사임당홀 | 예매가능	2026-05-29	2026-05-29	2026-05-30	upcoming	강릉아트센터 사임당홀	행사	https://gn.moonhwain.net:451/upload/pfm/202604/pImg1365_1.jpg	\N	https://www.gn.go.kr/yeyak/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=6422&searchYear=2026&searchMonth=05&searchSiteId=yeyak&searchMoon_p_idx=1365	강릉시청 공연/행사	033-660-6800	html	draft	\N	2026-05-25T00:00:08.011Z	2026-05-24 06:11:38.715692	\N	\N
ee136565ad389187cfd19414f7653371	클라라 주미 강 ＆ 김선욱 듀오 콘서트	오후 7시 30분 | 120분(인터미션 15분 포함) | 강릉아트센터 사임당홀 | 예매가능	2026-05-26	2026-05-26		tomorrow	강릉아트센터 사임당홀	행사	https://gn.moonhwain.net:451/upload/pfm/202602/pImg1343_1.jpg	\N	https://www.gn.go.kr/yeyak/selectMoonhwainView.do?pageUnit=999&pageIndex=1&searchCnd=all&key=6422&searchYear=2026&searchMonth=05&searchSiteId=yeyak&searchMoon_p_idx=1343	강릉시청 공연/행사		html	draft	\N	2026-05-25T00:00:08.011Z	2026-05-25 00:00:18.347988	\N	\N
859f21349c76a7808d83b279c981af21	유스 디자이너 클래스	교육/강좌 | 3층 나래실	2026-04-24	2026-04-24	2026-07-03	ongoing	3층 나래실	행사	https://www.gn.go.kr/site/yeyak/images/program/edu_list_image.jpg	\N	https://www.gn.go.kr/yeyak/unityProgrmWebView.do?key=5411&progrmNo=1343	교육/강좌	033-660-2393	html	draft	\N	2026-05-25T00:00:05.517Z	2026-05-25 00:00:18.347988	\N	\N
17cd3807b48a3da2a9b241d450750e34	감성 성장 뮤지컬 프로젝트	교육/강좌 | 2층 다목적실	2026-04-23	2026-04-23	2026-06-25	ongoing	2층 다목적실	행사	https://www.gn.go.kr/site/yeyak/images/program/edu_list_image.jpg	\N	https://www.gn.go.kr/yeyak/unityProgrmWebView.do?key=5411&progrmNo=1342	교육/강좌		html	draft	\N	2026-05-25T00:00:05.517Z	2026-05-24 06:11:38.715692	\N	\N
bf78af0843cf9f590ac7f9dda428e120	숲해설	체험/견학 | 강릉솔향수목원	2026-03-17	2026-03-17	2026-12-10	ongoing	강릉솔향수목원	행사	https://www.gn.go.kr/site/yeyak/images/program/tour_list_image.jpg	\N	https://www.gn.go.kr/yeyak/unityExprnWebView.do?key=5532&exprnNo=196	체험/견학	033-660-2323	html	draft	\N	2026-05-25T00:00:05.535Z	2026-05-24 06:11:38.715692	\N	\N
293944f4b93c22857d9aa95107467360	유아숲교육	체험/견학 | 강릉솔향수목원  유아숲체험원	2026-03-17	2026-03-17	2026-12-10	ongoing	강릉솔향수목원  유아숲체험원	행사	https://www.gn.go.kr/site/yeyak/images/program/tour_list_image.jpg	\N	https://www.gn.go.kr/yeyak/unityExprnWebView.do?key=5532&exprnNo=195	체험/견학	033-660-2323	html	draft	\N	2026-05-25T00:00:05.535Z	2026-05-25 00:00:18.347988	\N	\N
a342343f1f0ba17c1e8280169e1976f0	지역예술가 전시공간 지원사업	현재교육 모집마감 지역예술가 전시공간 지원사업 교육일자 2026-04-29 ~ 2026-08-30 교육장소 강릉시립미술관(교동) 교육대상 전체 연령.	2026-04-29	2026-04-29	2026-08-30	ongoing	강릉시립미술관	행사	https://gnmu.moonhwain.kr:447/upload/pfm/202604/pImg154_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=154	강릉시립미술관	033-660-2446	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-24 06:11:38.715692	\N	\N
a2b925738ae52231e646a77b17abb9bc	장욱진의 대화: 서로가 된 풍경	현재교육 모집중 장욱진의 대화: 서로가 된 풍경 교육일자 2026-04-01 ~ 2026-07-05 교육장소 강릉시립미술관(솔올) 교육대상 모든연령 입장가능합니다. 신청하기	2026-04-01	2026-04-01	2026-07-05	ongoing	강릉시립미술관	지역소식	https://gnmu.moonhwain.kr:447/upload/pfm/202603/pImg147_1.png	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=147	강릉시립미술관	033-660-2446	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
bda698a0c3367e9ab6f2740c196f7de1	사색의 운동회-장애물을 긍정하며	현재교육 모집중 사색의 운동회-장애물을 긍정하며 교육일자 2026-04-29 ~ 2026-06-10 교육장소 강릉시립미술관(교동) 교육대상 모든 연령 입장가능합니다. 신청하기	2026-04-29	2026-04-29	2026-06-10	ongoing	강릉시립미술관	지역소식	https://gnmu.moonhwain.kr:447/upload/pfm/202604/pImg151_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=151	강릉시립미술관	033-660-2446	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
fe79166d77410eea6c13053ae4b2ee45	전시연계 교육《좋았어 장애물》	현재교육	2026-05-09	2026-05-09	2026-05-30	ongoing	강릉시립미술관	행사	https://gnmu.moonhwain.kr:447/upload/pfm/202604/pImg153_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=153	강릉시립미술관		html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
0ce571844e2e9f91651295549d97b40f	전시연계 교육《행복한 우리집》	현재교육 모집마감 전시연계 교육《행복한 우리집》 교육일자 2026-05-09 ~ 2026-05-30 교육장소 강릉시립미술관(솔올) 교육대상 회차별 참여 대상 확인 필수	2026-05-09	2026-05-09	2026-05-30	ongoing	강릉시립미술관	행사	https://gnmu.moonhwain.kr:447/upload/pfm/202604/pImg152_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=152	강릉시립미술관	033-640-4271	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
af820e7f6c4da858aacc560d3636aefe	뮤지엄 나이트: 퇴근 후 미술관 (장욱진)	예정교육 모집중 뮤지엄 나이트: 퇴근 후 미술관 (장욱진) 교육일자 2026-05-29 ~ 2026-05-29 교육장소 강릉시립미술관(솔올) 교육대상 성인(직장인) 신청하기	2026-05-29	2026-05-29	2026-05-29	upcoming	강릉시립미술관	지역소식	https://gnmu.moonhwain.kr:447/upload/pfm/202605/pImg155_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=155	강릉시립미술관	033-660-2446	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
f78155f2e7b382599afd64f3c375c8ed	1회차_물리학의 눈으로 본 미술	예정교육 모집마감 1회차_물리학의 눈으로 본 미술 교육일자 2026-05-28 ~ 2026-05-28 교육장소 강릉시립미술관(솔올) 교육대상 성인	2026-05-28	2026-05-28	2026-05-28	upcoming	강릉시립미술관	지역소식	https://gnmu.moonhwain.kr:447/upload/pfm/202605/pImg158_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=158	강릉시립미술관	033-660-2446	html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
fd0c9c124c1cdb4cb43e169b6e60f980	전시연계 특별강연《나의 아버지 장욱진》	예정교육	2026-05-27	2026-05-27	2026-05-27	upcoming	강릉시립미술관	행사	https://gnmu.moonhwain.kr:447/upload/pfm/202605/pImg157_1.jpg	\N	https://www.gn.go.kr/mu/selectMoonhwainView.do?pageUnit=8&pageIndex=1&searchCnd=all&key=6620&searchMoon_p_team=gnmu&searchSiteId=mu&searchMoon_p_idx=157	강릉시립미술관		html	draft	\N	2026-05-25T00:00:05.769Z	2026-05-25 00:00:18.347988	\N	\N
a06b7272fe5d4d856d1020a17b7bcaa5	[포토뉴스]연곡면 이장협의회, ‘우리동네 새단장’시민 대청소 추진	연곡면 이장협의회(회장:손용수)는 2026 강릉세계마스터즈탁구선수권대회 및 강릉단오제를 맞아 많은 관광객이 강릉을 방문할 것으로 예상됨에 따라, 자체 환경정비 계획을 수립하고 관광지 및 취약지역을 대상으...				dateUnknown	강릉	핫플	https://www.kwnews.co.kr/photos/2026/05/22/2026052250022900000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250023100000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-24 06:11:38.715692	\N	\N
1710b218cc5e1420fa9e522e7d14ed88	강릉시, 대만 국제관광박람회 참가…‘강릉 방문의 해’ 해외 홍보 본격화	강릉시가 대만 대표 관광박람회에 참가해 ‘2026-2027 강릉 방문의 해’와 연계한 해외 관광마케팅에 본격 나선다.\n강릉시는 22일부터 25일까지 대만 타이베이 세계무역센터에서 열리는 ‘2026 타이베이 국제 관광박...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250023200000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250023400000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-24 06:11:38.715692	\N	\N
72706387ccd8c84751e8d349eeb63390	파마리서치, 강릉 제5공장 착공…글로벌 생산거점 확대	재생의학 전문기업 ㈜파마리서치가 글로벌 시장 확대에 맞춰 강릉 제5공장 건립에 나서며 글로벌 생산거점 확대를 본격화했다.\n파마리서치는 22일 강릉시 사천면 방동리 강릉과학산업단지에서 제5공장 착공식을 ...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250020900000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250021000000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-24 06:11:38.715692	\N	\N
e325d4728c2fe9c39124ce599fc5d848	파마리서치, 강릉 제5공장 착공…글로벌 생산거점 확대 본격화	글로벌 에스테틱 시장 확대에 맞춰 재생의학 전문기업 ㈜파마리서치가 강릉 제5공장 건립에 나서며  글로벌 생산거점 확대를 본격화했다.\n파마리서치는 22일 강릉시 사천면 방동리 808-17 일원 강릉과학산업단지...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250015800000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250016000000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.039Z	2026-05-25 00:00:18.347988	\N	\N
807b1838a9f5bf369ef571bc58183f84	[사설] ‘강호축 철도망’ 공약(空約)되면 안된다	여당인 더불어민주당의 정청래 대표와 우상호 강원지사 후보, 신용한 충북지사 후보, 민형배 전남광주통합특별시장 후보가 지난 19일 국회에서 ‘합동 공약발표회’를 갖고 강원지역의 주요 SOC 현안이자 국가균형발전차원에서 꼭 필요한 프로젝트인 ‘강호축 철도망’ 구축사업을 중앙당 차원에서 추진하겠다고 발표했습니다. 정 대표는 이 자리에서 “강호축 철도망 공약은 강원·충청·전라도 지역 주민들의 숙원인 ‘메가 공약’”이라며 실천을 다짐했습니다.강원도의 ‘강(江)’과 호남의 ‘호(湖)’를 따서 만든 ‘강호축’은 강릉∼원주∼제천∼청주공항∼익산∼목				dateUnknown	강릉	지역소식	\N	\N	https://www.kado.net/news/articleView.html?idxno=2051974	강원도민일보-강릉		rss	draft	\N	2026-05-25T00:00:05.402Z	2026-05-25 00:00:18.347988	\N	\N
35954b53c36afa02f655ffbb6dc30259	강릉문화원, ‘2026 꿈의 예술단 플러스 시범운영 거점기관’ 최종 선정-강원일보	강릉문화원은 문화체육관광부와 한국문화예술교육진흥원이 주관하는 ‘2026 꿈의 예술단 플러스 시범운영 거점기관’ 공모사업에 최종 선정됐다고 11일 밝혔다.\n	2026-05-12	2026-05-12		today	강릉	지역소식	\N	\N	https://kwnews.co.kr/page/view/2026051150088600000?area=W100000800003	강원일보-강릉		html	approved	\N	2026-05-11T21:28:50.441Z	2026-05-24 06:11:38.715692	\N	\N
443966a31457cd34c58042fbaf106e14	2026년 강릉차문화축제, 15일 개막-강원일보	‘2026 강릉차문화축제’가 오는 15일부터 17일까지 강릉오죽한옥마을 일원에서 개최한다.\n율곡국학진흥원에서 주관하는 올해 축제는 ‘말차, 초록의 위로’를 주제로, 바쁜 일상에서 차 한 잔이 주는 여유와 치유의 가치를 시민과 관광객에게 전할 예정이다.	2026-05-12	2026-05-12		today	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/11/2026051150011400000_l.jpg	\N	https://kwnews.co.kr/page/view/2026051150011600000?area=W100000800003	강원일보-강릉		html	approved	{"title": "2026년 강릉차문화축제, 15일 개막-강원일보", "caption": "✨ 2026년 강릉차문화축제, 15일 개막-강원일보\\\\n🗓️ 2026년 5월 12일\\\\n📍 강릉\\\\n\\\\n‘2026 강릉차문화축제’가 오는 15일부터 17일까지 강릉오죽한옥마을 일원에서 개최한다.\\\\n율곡국학진흥원에서 주관하는 올해 축제는 ‘말차, 초록의 위로’를 주제로, 바쁜 일상에서 차 한 잔이 주는 여유와 치유의 가치를 시민과 관광객에게 전할 예정이다.", "hashtags": ["강릉핫플", "강릉축제", "강릉", "국내여행", "강릉행사", "강원도", "PLAY강릉", "강릉나들이"], "createdAt": "2026-05-12T00:13:11.507Z"}	2026-05-11T21:28:50.441Z	2026-05-24 06:11:38.715692	\N	\N
6576ba14f3a11a21b2161f4861cff10f	[6·3 지선]강릉 찾은 우상호·정청래 “AI 데이터센터·호남 직결 KTX로 강릉 대전환 시작”	우상호 더불어민주당 강원도지사 후보가 22일 강릉 주문진시장에서 김중남 강릉시장 후보와 함께 집중 유세를 열고 강릉·영동권 경제 대전환 비전을 제시하며 시민 지지를 호소했다.\n이날 유세에는 정청래 더불어...				dateUnknown	강릉	행사	https://www.kwnews.co.kr/photos/2026/05/22/2026052250026100000_l.jpg	\N	https://kwnews.co.kr/page/view/2026052250026300000?area=W100000800003	강원일보-강릉		html	draft	\N	2026-05-25T00:00:04.038Z	2026-05-24 06:11:38.715692	\N	\N
6971dde679c71bec47bbc4d12627a953	‘유스컵 강호’ 중경고 3년 만에 금강대기 왕좌 재탈환	유스컵 창설 이후 단 한 번도 입상을 놓치지 않고 있는 중경고가 3년 만에 왕좌를 재탈환하며 저학년부 강호의 위용을 공고히 했다.중경고는 24일 오전 강릉 강남축구공원1구장에서 열린 2026 금강대기 고등학교 U17 유스컵 결승에서 대구공고와 연장 혈투 끝에 1-0으로 신승을 거뒀다. 이로써 중경고는 이번 유스컵 피날레를 전승 우승으로 장식했다.조별리그에서 3전 전승(승점 9)으로 5조 1위를 차지한 중경고는 16강에서 광주시G스포츠클럽을 4-1로 완파했고 8강에서는 JHLFCU18과 전후반 0-0으로 우열을 가리지 못한 뒤 승부차				dateUnknown	강릉	행사	https://cdn.kado.net/news/photo/202605/2051955_858130_2448.jpg	\N	https://www.kado.net/news/articleView.html?idxno=2051955	강원도민일보-강릉		rss	draft	\N	2026-05-25T00:00:05.403Z	2026-05-25 00:00:18.347988	\N	\N
56c4028a37a4b2080636e14795382a23	강원도 제2청사 농촌일손돕기	강원도 제2청사(본부장 손창환) 직원 40여 명은 22일 강릉 연곡면 딸기 농장을 방문, 농촌일손돕기 봉사활동을 했다.				dateUnknown	강릉	행사	https://cdn.kado.net/news/photo/202605/2051950_858127_2441.jpg	\N	https://www.kado.net/news/articleView.html?idxno=2051950	강원도민일보-강릉		rss	draft	\N	2026-05-25T00:00:05.403Z	2026-05-25 00:00:18.347988	\N	\N
67b188fa8c2192cf74183a3cd695be38	[선택 2026 강원] 지원사격·원팀 공조…연휴 달군 강릉 선거전	석가탄신일이 낀 연휴 기간에 6·3지선이 당의 지원사격과 후보간 공조 연합 전선이 펼쳐지는 등 뜨겁게 달아 오르고 있다.더불어민주당 정청래 총괄상임선대위원장(당대표)은 지난 22일 보수 텃밭인 강릉을 찾아 표심 공략에 나섰다.정 위원장은 이날 주문진에서 우상호 도지사 후보와 김중남 강릉시장 후보 지지를 적극 호소했다.정 위원장은 “더불어민주당 차원에서 전폭적으로 지원하겠다는 약속을 드린다. 강원도에 필요한 맞춤형 공약, 맞춤형 주문 바로바로 들어드리겠다. 당과 이재명 정부에서 집권이후 1년동안 가장 신경을 많이 쓰고 공을 들인 곳이				dateUnknown	강릉	지역소식	https://cdn.kado.net/news/photo/202605/2051942_858117_2430.jpg	\N	https://www.kado.net/news/articleView.html?idxno=2051942	강원도민일보-강릉		rss	draft	\N	2026-05-25T00:00:05.403Z	2026-05-25 00:00:18.347988	\N	\N
\.


--
-- Data for Name: meta_ad_insights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meta_ad_insights (id, ad_id, ad_name, ad_set_id, ad_set_name, campaign_id, campaign_name, date_start, date_stop, impressions, clicks, spend, reach, frequency, ctr, cpc, cpp, status, health_status, health_issues, collected_at) FROM stdin;
\.


--
-- Data for Name: meta_campaign_budgets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.meta_campaign_budgets (campaign_id, campaign_name, daily_limit, updated_at) FROM stdin;
\.


--
-- Data for Name: rotation_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rotation_rules (id, pool_id, ad_id, hour_slot, weight, status, created_at, ai_reason) FROM stdin;
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stories (id, title, body, images, source_url, author, tags, status, created_at, updated_at) FROM stdin;
36fa13277e728472	[위장일지#8] 경양식의 근본이 느껴지는 강릉 돈까스 맛집......	어언 2n년 전이니 핫밀이 강릉돈까스 맛집으로 얼마나 근본이 있는지 알수 있습니다... 히야 옛날엔 돈까스 먹고 싶어서 수요일 학교 일찍 끝나는 날마다 돈까스 먹으러가자고 그랬는데... 이젠 제 나이가...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNTYg/MDAxNzc4ODMwNTQ0MDMz.p7SVX7ghPQT2W6m5iJaicr7oQnkBRtvAK379eVqik0Mg.BIwSzavufSMAs_yplE5qQaY00kkdZb8G1SXR93SujmYg.JPEG/900_20260511_120615.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjMg/MDAxNzc4ODMwNTQ0ODk1.7GRuNAa9LWCp41IzXKUDkqxIz9UfdFxazCELhojJ4jIg.r7S3SX6mpq7Oiacbbd1SUKA2hPMcUMYeYIQ8R8_oaTQg.JPEG/900_1778829972249.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNjIg/MDAxNzc4ODMwNTQwMTU5.nP4KSx4B3jdkxxCp-jv8XCGq8d_xLqNCVEaCx0XYr-Qg.bHSXWMZkTucH03TI2ayo0R9yQvjC-FSInmziNfMjL2Ag.JPEG/900_1778830030681.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTk0/MDAxNzc4ODMwNTQxMzQ3.kiMrGuDZllKkkEjodLMAtssBghtxPbTl5RopI7Q04Pcg.v-SkuKiiRVTdRCHhJhlXgpZSAB32-4IUeYGJdYGPoEog.JPEG/900_1778830031070.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNDcg/MDAxNzc4ODMwNTQyMzcz.U6K-D7n2Ri_ZXwAiGr6vSmE7abpww2wO_Ve7VF1hA6kg.QPCs46DGbdm8BEg5XI55yUkHMYLL32vc-8ftY_lgV20g.JPEG/900_20260511_120654.jpg?type=w800"]	https://blog.naver.com/yakchow/224286556261	공주(진)일기장	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:17.934
a6228aa4408c8c1e	#주문진1박2일	점심으로 #중앙집식당에서 #갈치조림 #현지인추천맛집 #저녁메뉴는 #주문활게에서 #대게로 #부천건어물 사장님이 추천 해 준데로 너무 맛있었어요 강릉에 왔으니 #도깨비촬영지 #순두부젤라또 도 바다...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTA5/MDAxNzc4ODI4MzI1ODU4.7cBkkgn951NZnuMWiMF6PUP5n6LxHD89VFHaAj64zkog.PAscCm5mqVtr2eMe0isna_OV1hMwp4V1704cBftxn28g.JPEG/IMG%EF%BC%BF4707.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjI4/MDAxNzc4ODI4MzI4MjQz.4I0GRg-xLuIpzOEYHdS3HPtqPnngqPs8tsabJyYk98Ig.X5J1HjuXQJDH0ov1mFp8O7JleL7B2__9POFRMXl2OyEg.JPEG/IMG%EF%BC%BF4706.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTIg/MDAxNzc4ODI4MzI2NjYw.dDyRaSE0SNFnXUaVv3B28xZ8V7iMYMxq6R1ImgS9JMsg.AGgMiiw_oREK18irqL9f_wNp9Do7dzgOYl10OpD0vucg.JPEG/IMG%EF%BC%BF4704.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjMx/MDAxNzc4ODI4MzI1MDE5.o7__LCxaPIiehcKPV69Hys4uWUNgajrirA7GYbDgOdIg.oouvM_8qeSW3KOza-rWPo4H1yY4N46tksCjj4VZnY8Ag.JPEG/IMG%EF%BC%BF4708.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjg0/MDAxNzc4ODI4MzI0NTcz.m3oqClRylv_aw4mTzCM87YmNGCoI27xB2JVrGYAO_TYg.Co2lZfNsV5jgCR5t4V9qndIWkNAe2egzeyTCToxSHi0g.JPEG/IMG%EF%BC%BF4709.jpg?type=w800"]	https://blog.naver.com/ysakong/224286553602	루시아쏭 포커스	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:18.936
986b4578c6c00624	일상	얼른 다음 맛집 탐방가자ㅠㅡㅠ 아 한미나 왤케 웃기지 진짜 가방 귀여워서 갓챠했는데 그림이랑... 잼구리는 강릉살면서 계속 오징어순대 먹고싶다함 맘만먹으면 시장에서 바로 사먹을 수 있지않나?ㅋㅋ...	["https://mblogthumb-phinf.pstatic.net/MjAyNjAyMjRfMTA4/MDAxNzcxOTIxMDYwODI2.P45gauKRVpJhn6WzprvtHAimmMZS64Wb02VAJUhfV0sg.pZG_rAfgv16wuQi1x7oBNs-6VukKcXi5AIlbCQl1NYAg.JPEG/IMG%EF%BC%BF9288.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA0MDNfMjg0/MDAxNzc1MjAwMTQ3NjI2.GzDYTqDkjMf931Qii0tr4bM559O6Ju7pWhrloTog5V0g.Bfk7EkeGFWcRitSYdkYq4e4eeopg1gPC7GoNKL9PNbkg.JPEG/SE-C770DAA4-DB66-4A1E-B81A-EFDB4CCD9F4D.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjAyMjRfMTIy/MDAxNzcxOTIxMDYwNTI0.DAQc9ApPSKXqcew5LvM6Fu94QY5vZrraY4H-HZ25c2Mg.eE41PfTUxKn7f272EitTtuPseXpvRZiTXrtVlPsHBsAg.JPEG/IMG%EF%BC%BF9322.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjAyMjRfMjI3/MDAxNzcxOTIxMDYwNjA1.sp3sRFlrSxvONT-Ailo4p1YRLMcLKwcTJCxfHPUbgIYg.z2U4Fdv5UVrZkF88O-UzFTrJfSxoO9UI3Tlin-6BTtAg.JPEG/IMG%EF%BC%BF9331.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjAyMjRfNTQg/MDAxNzcxOTIxMDU5Mzc5.GQvV-VUD-_vtxpTbXQVJ-8JHNonhOfFyBUNZgbIgPi4g.IKBa-V9hPTJZLXIA5IWD4SlK7LHvrJeDBwjwTny_bM8g.JPEG/IMG%EF%BC%BF9328.jpg?type=w400"]	https://blog.naver.com/d0_0_e/224286550982	Be confident ◡̈	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:20.424
ce55bb465a18d78e	스카이바이크 주문진 도깨비촬영지 순두부짬뽕 강릉 가볼만한곳	위치 강원 강릉시 주문진읍 주문진리 방사제 인근 이용 요금 · 시간 무료 / 상시 개방 (주차장 별도 유료) 강릉 순두부짬뽕 맛집 강릉 여행 왔으면 강릉 순두부짬뽕은 필수죠! 강릉은 초당 순두부가 유명한...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjcw/MDAxNzc4ODMwMDg0NDYz.cEHfORjxOsgZAnTcQETDEUAcZwiWbclflonqr3_ha2Ag.aroSWWn_0VNolG08qHiZ1kB0-y4p0PUtvPUu4bqxi5cg.PNG/%EA%B0%95%EB%A6%89%EA%B0%88%EB%A7%8C%ED%95%9C%EA%B3%B3.png?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNTIg/MDAxNzc4ODI0Mzg1Mjkx.08sJ-__p_Guu4iVeH2y92NR1ebi6rjSAbgQlEkdv4pIg.hjVM1gYcIwxNDFecs_Fjc5oPd4GQpzOhkhuvDeXjXzgg.PNG/IMG%EF%BC%BF3408.PNG?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjcz/MDAxNzc4ODI0NzMyNjM0.uiZOVMFjbKUZxv7_Ja9Uqy-m0a8fBEa33fRxOzSAMpMg.Q7-JCE0CRS1BnsZ-X1Br-Jm03Y-AsLKihrZFJqD5i1Qg.PNG/IMG%EF%BC%BF3411.PNG?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTQ3/MDAxNzc4ODI1NjUyNTUw.-rk8ne3K680Zpuqd9gBk5GC39rP-HkkSRkZRejSmGKsg.3aeoZ2EIY_ByraNlfIMMorUjzEimLCmZviSO4vyEvhsg.PNG/IMG%EF%BC%BF3414.PNG?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjc3/MDAxNzc4ODI2MDQ3MDc0.2Eij5dqPKIms1ooynHnzFA4qCzYbl3_TXirUDHxE9y4g.kNYNBjdnT_kGoCcDrJVR8x3i8LtvmQB6kp7zRWyQpVsg.PNG/IMG%EF%BC%BF3416.PNG?type=w800"]	https://blog.naver.com/yunsllog/224286535713	별따라여행	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 12:08:05.011
444eba23579732fc	강릉 1박2일 맛집 추천 : 주문진 소도리 식당, 소돌엔 카페 정보	이렇게 주문진에서 여행하면서 가본 식당(소도리)과 카페(소돌엔), 포장마차를 소개해드렸는데, 모두 서울에서 버스 한 번으로 닿을 수 있는 강릉 주문진으로 여행 가셔서 다양한 맛집을 즐겨보셨으면...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTRfMjkx/MDAxNzc4NzE5MzgzMTQ5.G1PMqyyWfcqNx5_zeOVCkxH_H09GJa9ohcJxoAhYkykg.eP7MpkeTRP5euY_rmOdw6VCK57AnC6Nr1N6qgLb_FKUg.JPEG/SE-c76e4f97-4ead-11f1-b55d-21988e60a33d.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTRfMTM1/MDAxNzc4NzE5Mzk3ODk3.UE9nk5l5SzgLC_1_Ut5vxjHnP822kXEreMTEgHsCrTUg.8bgdLWJmhOfJ7GzZUtgJAdAklreC6jeR78sNLDyxrOwg.JPEG/SE-c774df48-4ead-11f1-b55d-7f06d19c8d93.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTk5/MDAxNzc4ODExNDc0Mzky.sHyzoYNwP1dRoDLvG5lNwaf_cG-q-FsZXI5V3nGyQcgg.-zAH2KpgOrjt8nkk29krv8sM7xxHGrBjHOu5STJr454g.JPEG/SE-52938a2d-79ce-42ad-95f3-99a52717e292.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTRfMTgw/MDAxNzc4NzE5Mjc0NjA3.IGTQZqbCJPhaAsPCaaiSfmAbB1K2hHkPDcGbycao5Qcg.iA6DtcumJ0Sd-vagzdDr4LKY6fJry04DUj002VoKF3kg.JPEG/SE-68382589-fc50-493e-b481-71290491ba66.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTRfMjE0/MDAxNzc4NzE5MjcyMzY0.CDQLob-nVKsCDv2NnmRKvE2caSeCKGH9LouedWSCsE4g.KC5Lb4NOLAEz6fvkk1eLNTUhL47FQZJhDhMW8BlJvi8g.JPEG/SE-b27d644b-87a7-4b12-847f-5aacd42a8222.jpg?type=w400"]	https://blog.naver.com/la929988/224286544878	R:LOG	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:22.036
e4ed0d8ff6b7479d	대구 신세계 백화점 팝업 5월 셋째주 강릉길감자, 양쯔깐루 등...	소호 베이크 상하이 양쯔깐루 메뉴 상하이 양쯔깐루 11,900원  강릉 길감자 강릉 중앙시장 맛집 강릉길감자가 지난주에 이어 이번주에도 대구 신세계 팝업 5월 셋째주에 참여해 많은 인기를 끌고 있어요...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjAz/MDAxNzc4ODI3NjI0NzQy.mPXvnLN8GztWOKiMFFkLjCRaed43n0ZyLzr-Hvvel88g.3zaBQ2VFPJtP01jr22Zk33VvvmKVN03rdcOm_XW-pHog.JPEG/KakaoTalk_20260515_154501505.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMzIg/MDAxNzc4ODI3OTUwMTg4.DwtIdR5vu61CNXcF4HA883y8JR5S8W4nogZxrwkzm9Ag.KvwszlkT2CuWjArq0iDTAN9N_MWHdmCJQ6P_xV-gux4g.JPEG/SE-b3ae12bc-2825-4c70-a3a7-5d1f1dc4819c.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTg4/MDAxNzc4ODI3OTE0NzIx.2-cH4c7IbeofMrUeG_BMwoM3Znde6zMMad1MdhhVy9Ug.h-E5FQLlY8B16Howv53O9KjD_BG_XtbTlFFXU9WlOKUg.JPEG/KakaoTalk_20260515_154114325.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNDEg/MDAxNzc4ODI3OTE0Njcy.wXyCTfvDClQihlpX3C7dhpSZZ_R-rpoBQsn0tcSuP5Eg.9LwFiorkTuP_oeZMASmXpKu0_-JC_YP2hWi9DjlCZoog.JPEG/KakaoTalk_20260515_154114325_02.jpg?type=w400", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTk4/MDAxNzc4ODI4Mjk0ODAw.aYSb3CyZBfS6r5Lnps6nnJrxeTuKFECS7_uehJUiU8wg.AGrHvDjsC55vqXx_oUKNWoDVROb2Nm9SzY8IuAd8krwg.JPEG/KakaoTalk_20260515_154114325_25.jpg?type=w400"]	https://blog.naver.com/ekxxccmm/224286540133	맛따라 발걸음따라	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 12:08:03.795
9e445ae30fd2254b	노승희 매치플레이 연승 행진…리 슈잉·김민선 반등 성공	한국여자프로골프투어(KLPGA)에서 유일하게 누적 타수가 아닌 홀별로 승부를 겨루는 매치플레이 방식으로 진행되는 ‘제18회 두산 매치플레이(총상금 10억원)’가 14일 춘천 라데나 골프클럽에서 2라운드를 소화하며 조별리그의 반환점을 돌았다. 강릉 연고 리쥬란 골프단 소속의 노승희는 1라운드에 이어 다시 한번 승전고를 울리며 토너먼트에 바짝 다가섰고 팀 동료인 리 슈잉과 원주 출신 김민선도 반등에 성공하며 희망의 불씨를 살렸다. 반면 춘천 출신 김민별과 속초 출신 한진선, 태백 출신 임희정은 조기 탈락이 확정됐다. 이날 2라운드에서	["https://www.kado.net/image/logo/snslogo_20250627101858.png"]	https://www.kado.net/news/articleView.html?idxno=2050323	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-26 00:51:38.215
cdeb1d838aed2405	국민의힘 강릉 후보자들 우상호·김중남 경찰 고발… 김중남 캠프 측 법적 조치 검토	김홍규 국민의힘 강릉시장 후보가 더불어민주당 우상호 도지사 후보와 김중남 강릉시장 후보를 공직선거법 위반으로 경찰에 고발했다.김홍규 시장 후보를 비롯한 국민의힘 강릉 선거구 후보자들은 15일 강릉경찰서 앞에서 김중남 후보·우상호 후보 공직선거법 위반사항에 대한 고발 기자회견을 개최했다.이들은 “김중남 강릉시장 후보는 강릉 물 부족 해결을 위한 예산 435억원 확보라는 명백한 허위 사실로 강릉시민을 기만했다”며 “강릉시 관련 예산은 72억에 불과하며 해당 예산은 가뭄 이전 강릉시 공무원들이 노력해 중앙정부와 협의해온 예산이다”고 주장	["https://cdn.kado.net/news/photo/202605/2050368_856099_5742.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050368	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
e14fd67a368e5993	강원FC K리그1 14라운드 베스트 팀 등극…김대원·모재현·이기혁은 베스트 11	적수가 없는 필승 공식으로 상승세를 이어가고 있는 오렌지 군단이 한 달 만에 최고의 팀을 재탈환했다.강원FC는 15일 한국프로축구연맹이 발표한 하나은행 K리그1 2026 14라운드 베스트 팀에 선정됐다. 앞서 6라운드와 7라운드에서 베스트 팀에 등극했던 강원FC는 7경기, 약 1개월 만에 다시 타이틀을 차지했다.강원FC는 지난 12일 강릉하이원아레나에서 열린 대전하나시티즌과 맞대결에서 아부달라와 김대원의 연속골에 힘입어 2-0 완승을 거뒀다. 이날 승리로 이번 시즌 5승 6무 3패(승점 21)를 기록한 강원FC는 6위에서 5위로 도	["https://cdn.kado.net/news/photo/202605/2050367_856097_5633.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050367	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
623bec7c0b857f45	금강대기 토너먼트 대진 확정…‘조별리그 전승’ 고양고·강릉문성고 16강서 격돌	‘구도(球都)’ 강릉 일원에서 펼쳐지고 있는 ‘2026 금강대기 전국 고등학교 축구대회’가 조별리그를 마무리한 가운데 국내 고등 최강 타이틀을 향한 승자 독식의 경쟁인 토너먼트 대진이 확정됐다.이번 대회는 지난 10일부터 14일까지 2일 간격으로 39팀이 10개 그룹으로 나뉘어 조별리그를 소화한 가운데 각 조 1위가 16강에 직행하고 각 조 2위가 추첨을 통해 16강 또는 20강에 편성됐다. 20강은 16일, 16강은 18일 강남축구공원과 강북공설운동장에서 나눠 진행된다.14일 조별리그 최종전 직후 진행된 대진 추첨 결과 16강에서	["https://cdn.kado.net/news/photo/202605/2050364_856093_3208.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050364	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
57c09b152c721c37	평창 방문 김병주 의원, 더불어민주당 후보 지원 나서	강릉 연고인 김병주 국회의원이 15일 평창읍을 방문, 더불어민주당 후보들의 선거운동을 지원했다.김 의원은 이날 오전 평창읍에 도착, 한왕기 더불어민주당 평창군수 후보, 이정균 도의원 후보, 임현우·이은미 군의원 후보, 김복준 군의원 비례대표 후보와 함께 평창읍 시가지와 평창5일장터를 돌며 상인과 주민들에게 인사하고 지지를 당부했다. 신현태 기자	["https://cdn.kado.net/news/photo/202605/2050362_856088_2441.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050362	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
c7720731d4b56bed	“벌써 여름” 강원 낮 최고 31도 불볕더위…주말엔 더 덥다	금요일인 15일 강원 지역은 대체로 맑은 날씨 속에 내륙을 중심으로 낮 기온이 30도 안팎까지 오르며 때 이른 초여름 더위가 기승을 부리겠다.기상청에 따르면 이날 오전 5시 기준 주요 지점 기온은 원주 15.3도, 춘천 13.7도, 강릉 12.5도, 동해 11.7도, 태백 5.8도 등을 기록했다. 해가 뜨면서 기온은 빠르게 상승해 낮 최고기온은 내륙 28∼31도, 산지(대관령·태백) 24도, 동해안 22∼25도까지 오를 것으로 예보됐다.전국적으로도 서울 32도, 대전 31도, 광주 30도 등 내륙 지역을 중심으로 고온 현상이 나타나	["https://cdn.kado.net/news/photo/202605/2050333_856048_0017.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050333	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
5adbf2d18c15b6ff	고양고·강릉문성고·화성시U18 전승 행진 ‘16강 직행’	‘구도(球都)’ 강릉 일원에서 펼쳐지고 있는 ‘2026 금강대기 전국 고등학교 축구대회’가 14일 조별리그를 마무리하고 토너먼트를 통해 국내 고등 최강 타이틀을 향한 승자 독식의 경쟁에 돌입한다.토너먼트는 16일부터 24일까지 20강을 시작으로 16강, 8강, 준결승, 결승이 이틀 간격으로 진행된다. 고학년부인 이 대회는 각 조 1위가 16강에 직행하고 각 조 2위는 추첨을 통해 16강 또는 20강에 편성된다.조별리그에서는 4조의 고양고와 7조의 강릉문성고, 9조의 화성시U18이 3전 전승(승점 9)으로 1위를 차지했다. 고양고는	["https://cdn.kado.net/news/photo/202605/2050322_856029_5440.jpg"]	https://www.kado.net/news/articleView.html?idxno=2050322	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
90bc3c063fa2e769	친정 찾는 양민혁…강원FC 2연승·5경기 무패 달릴까	‘초신성’ 양민혁(코번트리 시티 FC·강릉제일고 졸업·사진)이 친정을 찾는다. 이 기운을 받아 오렌지 군단이 2연승과 5경기 무패 행진으로 월드컵 휴식기를 가질 수 있을지 주목된다.강원FC는 오는 17일 오후 7시 강릉하이원아레나(강릉종합운동장)에서 울산HD와 하나은행 K리그1 2026 15라운드 맞대결을 치른다. 현재 강원은 5승 6무 3패(승점 21)로 5위, 울산은 8승 2무 4패(승점 26)로 2위에 올라 있다.강원은 이달 4경기에서 무패 행진을 달리고 있다. 인천유나이티드와 포항스틸러스, 광주FC, 대전하나시티즌을 상대로	["https://cdn.kado.net/news/photo/202605/2050320_856028_152.png"]	https://www.kado.net/news/articleView.html?idxno=2050320	강원도민일보 강릉	["강릉", "지역소식", "2026"]	approved	2026-05-15 06:58:21.271552	2026-05-15 06:58:21.271552
8fdffd423efbd1dd	5월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 사랑과 행복이 가득한 가정의 달 5월! 가족과 함께 즐거운 시간 보내고 계시나요? 그럼, 이웃님들과 함께 하면 좋을 2026년 5월 이달의 블로그를 소개합니다! 5월의 주제는 게임은 스포츠다! 이 세상 모든 게임 공략을 모았어요. 게임 블로그 귀여운 반려동물을 위해 반려인이 꼭 알아야 할 상식 모음.ZIP 반려동물 블로그 모든지 처음이 어려워요! 어려운 경제 이야기 쉽게 풀어줄게요~ 비즈니스·경제 블로그 영화는 두 번 시작된다! 보면 볼수록 매력적인 영화를 소개해요~ 영화 블로그 이달의 블로그에 선정되신 분들, 모두 축하합니다! 이달의 블로그란? 이달의 블로그는 주제별 좋은 블로그를 쉽게 찾아.......	["https://blogthumb.pstatic.net/MjAyNjA0MjRfMTQ0/MDAxNzc3MDE4MTI3NDUw.axaGPQ-NEFsiLNym05jcVHueux4qVB537Wx3Yt6fnMkg.qCiAmYmf2Aptvz-7vMC8vayTKUGOwH_bF7SmCwxqaIYg.PNG/%BC%D2%B0%B3_05.png?type=s3"]	https://blog.naver.com/blogpeople/224281510266?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
1a51f3d4682ca76e	(당첨자 발표 완료)[깜짝 이벤트] 제62회 백상예술대상 후보작 리뷰하고, 시상식 초대권 받아 가세요 ✨✨	안녕하세요, 네이버 블로그팀입니다. 꽃이 만개한 요즘, 산뜻한 봄날 보내고 계시나요? 화창한 계절을 맞아 블로그팀에서 아주아주 특별한 선물을 준비했는데요! 바로바로 지난 1년간 우리의 마음을 설레게 하고, 함께 웃고 울었던 작품과 예술인들을 한자리에서 만날 수 있는 백상예술대상 X 블로그 리뷰 이벤트 입니다! 그럼 어떤 이벤트인지, 지금 바로 함께 살펴볼까요? 참여 방법 제62회 백상예술대상 후보 중 내가 응원하는 작품(방송 · 영화 · 연극 · 뮤지컬)에 대한 이야기를 여러분의 블로그에 기록해 주세요! > > 제62회 백상예술대상 후보작 보러 가기 리뷰, 기대평, 응원 글 등 자유롭게 남겨 주시면 OK! 여러분만의 &#x2.......	["https://blogthumb.pstatic.net/MjAyNjA0MjRfNzIg/MDAxNzc3MDEzNjYxOTEz.7FuXH5K0TcL8d2iDI0xsKWXHWgy8EAf29k1j7AtN4Skg.AtXO7PTRKGaOAdYgX8VllAl8vRhZHN4AEBh4I9DXrukg.PNG/%BA%ED%B7%CE%B1%D7%C6%C0_%B0%F8%C1%F6_%C0%CC%B9%CC%C1%F6_1.png?type=s3"]	https://blog.naver.com/blogpeople/224263801063?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
5db725bfbbd52819	5월, 이달의 블로그를 추천해 주세요!	2026년 5월의 주제는 게임, 비즈니스·경제, 영화, 반려동물 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1. 본인의.......	["https://blogthumb.pstatic.net/MjAyNjA0MDNfMjE1/MDAxNzc1MjA5NjYxODIx.x-xoYCVnUDgqCw3t4OeMezax_OhZB-L4DS4v-IdLMbsg.zcrlX_2u2k17FRb-6fiZtKQDJqGuiZQ3cdxTNpV2-awg.PNG/%C3%DF%C3%B5_05_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224258875431?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
a262195a71d4f733	[스마트에디터 ONE]  새롭게 추가된 부동산 글감을 사용해 보세요	안녕하세요. 네이버 블로그팀입니다. 풍성한 글을 만들어주는 글감 기능, 모두 잘 사용하고 계시나요? 오늘은 더욱 폭넓은 활용을 위해 새롭게 추가된 글감을 소개해 드리려고 합니다. 새로운 글감은 바로바로... 부동산 글감 블로그에서는 아래의 사례들처럼 다양한 부동산 관련 글을 찾아볼 수 있는데요! ✍ 직접 발로 뛴 임장 기록 ✍ 꼼꼼한 부동산 시장 분석 ✍ 놓칠 수 없는 청약, 공공임대 정보 이렇게 소중한 정보들을 더욱 편리하게 작성할 수 있도록 부동산 글감이 탄생하였습니다. 앞으로 부동산 글감을 사용해서 글을 완성하면 블로그를 작성하며 손쉽게 시세 정보를 찾아볼 수 있고, 나아가 부동산 글감 피드를 통.......	["https://blogthumb.pstatic.net/MjAyNjA0MDlfMjQy/MDAxNzc1Njk4NzI2NzQ2.U_VaNfMIdYoZX_77VeVFiGbckCIEl-F85nPSYvRUCWIg.JDQUIOXYJc3pqk0Tk0MUwJFi1bjRnoVizEv_srMODosg.PNG/%C5%B8%C0%CC%C6%B2.png?type=s3"]	https://blog.naver.com/blogpeople/224246243521?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
5b69f2f79b00cb34	4월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 코가 간질간질 벌써 봄이 왔나봐요! 벚꽃 보러 갈 생각에 설레이는 요즘이네요~ 그럼, 이웃님들과 함께 하면 좋을 2026년 4월 이달의 블로그를 소개합니다! 4월의 주제는 자동차에 대한 모든 이야기 세상 모든 자동차를 탐구하고 싶어요! 자동차 블로그 책 속에 빠져 사는 나날들 매일 읽고 생각하고 기록해요~ 문학·책 블로그 혼자 또 같이 먹어요~ 건강하고 맛있게 만드는 레시피 기록 요리·레시피 블로그 맛있는게 최고야 짜릿해! 전국구 숨은 맛집들을 찾아서~ 맛집 블로그 이달의 블로그에 선정되신 분들, 모두 축하합니다! 이달의 블로그란? 이달의 블로그는 주제별 좋은 블로그를 쉽게 찾아볼 수 있도.......	["https://blogthumb.pstatic.net/MjAyNjAzMjNfMjk0/MDAxNzc0MjU0NDQxNjUx.wgW_8k1Q9kjhh0pDL2QzwcWrRJXomc5lIqXHzBmARmUg.YMB2NZORw_qakOT7otW_X3EZQ6NXVm-zCkUku3O70DMg.PNG/%BC%D2%B0%B3_04.png?type=s3"]	https://blog.naver.com/blogpeople/224245253227?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
52289fa9067bf60b	탐색탭에서 내 취향 글 읽으면 매일 랜덤 포인트 드려요!	안녕하세요, 네이버 블로그팀입니다! 오늘은 탐색 피드를 즐기는 여러분께 특별한 이벤트 소식을 가져왔습니다. 탐색탭에서 내 취향에 맞는 글을 읽기만 해도 네이버페이 포인트를 받을 수 있다면?! 참여 방법은 아주 간단! 정말 간단해요 블로그 탐색탭에 들어오시면 자동으로 이벤트에 참여됩니다. 별도 신청도, 참여 버튼도 없어요! 평소처럼 탐색탭에서 보이는 글 중 최소 2개 이상 관심 가는 글을 읽다 보면 어느새 미션 달성! 미션을 달성하고 탐색탭으로 돌아온 순간 보상 팝업이 짠! 하고 나타납니다 ✨ *해당 이벤트는 모바일 환경에서만 참여할 수 있어요. 탐색탭에서 보이는 내 취향 글 2개 이상 읽.......	["https://blogthumb.pstatic.net/MjAyNjAzMjNfMTgg/MDAxNzc0MjQ5MTEzNTU5.hFJ5MUz9E-nMBDZXCENAX16VHkEMozYOBAsB_9-Jw0Ig.gZSw_9QlgN3elj-sM76Gk2uxnM_QTbMgqZ-WZfWwncog.PNG/%C5%BD%BB%F6_%BC%D2%BA%F1_%C7%C1%B7%CE%B8%F0%BC%C7_01_%C5%B8%C0%CC%C6%B2.png?type=s3"]	https://blog.naver.com/blogpeople/224234801764?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
fc4427eceb87e1ea	블로그 검색결과에서 '내돈내산' 글만 모아볼 수 있어요!	안녕하세요. 네이버 블로그팀입니다. 블로그에서 검색할 때 "찐 내돈내산 글만 보고 싶은데.." 싶었던 적 있으셨나요? 광고 없이 직접 구매하거나 직접 경험한 글, 이제 블로그 검색에서 쉽게 찾을 수 있습니다! ① 검색 옵션 내돈내산 필터 추가 블로그 서비스 검색 > 검색결과 > 글탭 에서 블로그 내돈내산 기능을 첨부하여 작성한 글이 있을 경우, '내돈내산 글만 보기' 필터가 보여집니다. 해당 필터를 클릭하면 직접 구매하고 방문한 내돈내산 글들만 쉽게 만나볼 수 있고요 내가 사고 싶었던 신상 립스틱의 찐 후기, 가고 싶었던 맛집의 생생한 리뷰를 검색 결과로 바로 찾아볼 수 있어요. 내돈내산 검색결.......	["https://blogthumb.pstatic.net/MjAyNjAzMjVfMjc1/MDAxNzc0NDI0MTEzOTMx.N-zJSS2I7ynHwbtCRaC0aspbeOZyZzbitelRHC7FxOog.-NcwgmyFozqRJ8cBhD2LNaTeYGJQgntDOTgRsSklZjUg.PNG/%B0%CB%BB%F6%B0%B3%C6%ED%B0%F8%C1%F6_01.png?type=s3"]	https://blog.naver.com/blogpeople/224229363471?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
719a4fdfcff35cc0	4월, 이달의 블로그를 추천해 주세요!	2026년 4월의 주제는 맛집, 자동차, 문학·책, 요리·레시피 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1. 본인의.......	["https://blogthumb.pstatic.net/MjAyNjAzMDVfMzgg/MDAxNzcyNjg0NTMzNjYw.6AS8Moydi288rmPm6GyQDZe5aLSorUPSm4kCEBWz5KEg.aPaerCkGzAeDlAFdXy8SZBAETI6QSfOCEs0zzMiCur4g.PNG/%C3%DF%C3%B5_04_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224229008653?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
ba307a5cd3c94f24	3월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 본격 따뜻한 봄이 시작되는 3월이에요! 두근두근 새학기 개강준비 잘 하고 계신지요~ 그럼, 이웃님들과 함께 하면 좋을 2026년 3월 이달의 블로그를 소개합니다! 3월의 주제는 국내외 스포츠를 사랑해요 더 재밌게! 더 맛있게! 스포츠 경기 해설해 드릴게요~ 스포츠 블로그 매일매일 드라마처럼 살고 싶어요! 드라마 덕후들의 인생 드라마는? 드라마 블로그 내가 살고 싶은 집은? 내 손으로 꾸미는 인테리어 디자인 내 손으로 꾸리는 살림의 모든 것! 인테리어·DIY 블로그 뮤지컬 전시 연극에 진심이에요! 감성을 건드리는 예술 공연을 기록합니다~ 공연·전시 블로그 어쩌다 정원 집사! 슬기로운 반려 식물 가.......	["https://blogthumb.pstatic.net/MjAyNjAyMjNfMTUy/MDAxNzcxODM2ODg0MTY2.MX3MDt6SKXtKhmuKE5x0sgVgf7pV-_4c3jyxj2FJVaUg.cNDhi6sNm5298TrvONczMaatMsdr543onraAFC3N3wYg.PNG/%BC%D2%B0%B3_03.png?type=s3"]	https://blog.naver.com/blogpeople/224212692732?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
badbd71b230bc3f8	3월, 이달의 블로그를 추천해 주세요!	2026년 3월의 주제는 스포츠, 어학·외국어, 공연·전시, 인테리어·DIY, 원예·재배, 드라마 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해.......	["https://blogthumb.pstatic.net/MjAyNjAyMDRfMjkw/MDAxNzcwMTY2MjI1OTA1._9Ue2kCTnUYD7XAsgfKOGnsE8auZqthg5Ed_Fm639Iog.YD82e_ssbowQCB3MG_DmUviDzvoXMLAHHYI5fQfTBqEg.PNG/%C3%DF%C3%B5_03_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224189586518?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
f073172dd90bff43	블로그 탐색 피드의 AB 테스트를 시작합니다	안녕하세요, 네이버 블로그 팀입니다. 다가올 2026년, 블로그 추천 피드가 '탐색 피드'로 새롭게 태어납니다. 그동안 블로그의 추천 피드는 많은 사용자가 선호하는 주제 중심으로 다양한 글을 볼 수 있는 공간이었습니다. 이번 개편을 통해 새로워진 블로그의 탐색 피드는 사용자의 관심사와 취향 데이터를 반영하여 나에게 맞는 글을 '발견'하고 '탐색'하는 공간으로 거듭날 예정입니다. 정식 오픈 전, 블로거 여러분의 취향을 더 잘 이해할 수 있도록 새로운 블로그 탐색 피드의 AB 테스트를 진행합니다. 새로운 블로그 탐색 피드는 일부 사용자를 대상으로 12월 15일부터 제공되며 품질 검증 및 개선을 위해 일.......	["https://blogthumb.pstatic.net/MjAyNTEyMDhfMjUg/MDAxNzY1MTk4NDAwODI1.yZ8_vncVs5uuSvxwp2oRt8BgtoN9YNrai_J9jcjQHKsg.UDnswnEp-5iZ6Ko4bThHtg9hClW_jaPWqr-7JJSyf_8g.PNG/%C5%BD%BB%F6%B0%B3%C6%ED_01__%C4%BF%B9%F6.png?type=s3"]	https://blog.naver.com/blogpeople/224110488703?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
2a823f86433a06d5	(이용권 지급 완료) [blog X 해피빈] 2026년 새해 첫 기부 인증 이벤트!	안녕하세요, 네이버 블로그팀입니다. 붉은 말의 해, 힘차게 시작하셨나요? 앞만 보고 달리기보다는 누군가와 보폭을 맞추며 함께 가는 한 해도 참 좋을 것 같다는 생각이 듭니다. 이 마음을 담아 해피빈과 블로그팀이 올해도 새해 첫 기부 인증 이벤트를 준비했어요! 기부는 특별한 결심이 없어도 시작할 수 있어요. 하루를 기록한 블로그 글 하나, 그 기록으로 받은 기부콩 하나로도 충분하니까요. 이 콩들이 모여, 학업을 이어가기 어려운 아이에게는 다시 책을 펼칠 수 있는 배움의 기회가 되고, 한겨울을 버티고 있는 유기동물에게는 오늘을 살아 낼 따뜻한 한 끼가 되어 줄 거예요. 모두가 같은 속도로 살지는 않지만, 일상을 기록하는 작은.......	["https://blogthumb.pstatic.net/MjAyNjAyMTJfNTEg/MDAxNzcwODcxNTk0NjA4.aBWSlg2_LFc06AsSMFsA3Sz4-VMSM6npCCJ9x4rrzDYg.XKo79aOKoP1fR6NBrdn1TDIOj_y5mdocZJlAGiJYFTog.JPEG/01.jpg?type=s3"]	https://blog.naver.com/blogpeople/224181351140?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
3505f4ace1ec677a	2월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 입춘이 지나고 2월을 맞이하고 있어요. 아직은 춥지만 따뜻한 봄이 벌써 기다려지네요 :) 그럼, 이웃님들과 함께 하면 좋을 2026년 2월 이달의 블로그를 소개합니다! 2월의 주제는 인생의 가장 중요한 순간은 지금! 일기일회 나의 국내여행 기록 국내여행 블로그 맛있는 미술 이야기 어렵지 않은 미술에 대해 알려드릴게요! 미술·디자인 블로그 하루하루 내 생각을 기록해요 소소하지만 감성적인 나의 일상들을 모아 일상·생각 블로그 뭐니뭐니해도 건강이 최고죠 생활 속 건강습관 이것부터 시작해요! 건강·의학 블로그 이달의 블로그에 선정되신 분들, 모두 축하합니다! 이달의 블로그란? 이달의 블로그는.......	["https://blogthumb.pstatic.net/MjAyNjAxMjNfMjYz/MDAxNzY5MTU1Mzg4MDc2.1r8yaOf6Mjbc8sK9IN2-PGQ8pn3qbdbZ3afy0G-OQzsg.b_hV2rPtHMpYBNVRgOtANbnYzfOi0UmYAc2F0wadCWsg.PNG/%BC%D2%B0%B3_02.png?type=s3"]	https://blog.naver.com/blogpeople/224179841464?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
973f07493e28f5ff	2월, 이달의 블로그를 추천해 주세요!	2026년 2월의 주제는 건강·의학, 미술·디자인, 일상·생각, 방송, 국내여행 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습.......	["https://blogthumb.pstatic.net/MjAyNjAxMDVfMTgy/MDAxNzY3NTg0OTEwMzc5.S9ctRJLp-MJA0NrctSgH7v_NJxPpzNivPUouv5Zs4MYg.6SihzpoC5CC7TJ1X-U0U_nF2vsuXF2EcSZnz4OQBfF4g.PNG/%C3%DF%C3%B5_02_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224160413024?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
284ca3dbe9d7d4d5	새로워진 블로그 탐색 피드를 만나보세요!	안녕하세요. 네이버 블로그 팀입니다! 새로운 탐색 피드를 테스트하고 있다는 지난 팀블로그 공지를 기억하시나요? AB 테스트 결과를 기반으로 1월 19일부터 모든 사용자에게 새로운 탐색 피드를 정식으로 오픈합니다! 이제 블로그 탐색 탭에서 마음에 드는 글을 탐색해보세요. 새로운 블로그 탐색 피드는 사용자의 관심사와 취향 데이터를 반영하여 나에게 맞는 글을 '발견'하고 '탐색'할 수 있는 공간입니다. 그럼 다시 한 번 블로그 탐색 피드의 주요 기능을 살펴 볼까요? 1. 피드를 자유롭게 탐색해보세요. 마음에 드는 글과 새로운 이웃을 발견할 수 있습니다. 2. 관심있는 주제를 선택하고 주제별 피드를 탐색해보세요.......	["https://blogthumb.pstatic.net/MjAyNjAxMTZfMTk5/MDAxNzY4NTU4MzE2ODA4.EKSJvObw2VHWxEVa-tZhsckDS1ZIaWdsx8As7ikWXAkg.M8P9Nnp45XRbRdQjzhYd_pYNgbAJobsjxOd_RXJe6zcg.PNG/%C5%BD%BB%F6%C5%C7%B0%B3%C6%ED%B0%F8%C1%F6_01.png?type=s3"]	https://blog.naver.com/blogpeople/224152137013?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
3e03f6a4a6555792	1월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 2026년 병오년이 시작되었네요. 모두 새해 복 많이 받으시고 행복한 일만 가득하시길 바랍니다 :) 그럼, 이웃님들과 함께 하면 좋을 2026년 1월 이달의 블로그를 소개합니다! 1월의 주제는 소박한 추억부터 화려한 아름다움까지 모두 담아두고 싶어요~ 사진 블로그 애니메이션에 진심인 사람 N년째 덕후생활 이어가는중~ 만화·애니 블로그 어렵지 않은 패션 이야기 취향 스타일 패션정보 공유해요 패션·미용 블로그 세상의 모든 IT기기를 리뷰해요 어렵지않은 테크 이야기를 담아~ IT·컴퓨터 블로그 이달의 블로그에 선정되신 분들, 모두 축하합니다! 이달의 블로그란? 이달의 블로그는 주제별 좋은 블로그를.......	["https://blogthumb.pstatic.net/MjAyNTEyMjRfMjMy/MDAxNzY2NTYyNzY1Nzkz._W93RsngImaKJTP-F7aK1s3d5BBcAiOi3SbczWwmQ-cg.Wr4omVhhklqltp5G4HaQrW7jYy1-_i0L25qbgTwWTf8g.PNG/%BC%D2%B0%B3_01.png?type=s3"]	https://blog.naver.com/blogpeople/224147690885?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
470ced8be459a5f3	10월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 무더웠던 여름이 지나고 드디어 가을의 문이 열리고 있어요. 선선한 바람과 함께 다가오는 계절의 시작을 기분 좋게 맞이하시길 바랍니다 :) 그럼, 이웃님들과 함께 하면 좋을 2025년 10월 이달의 블로그를 소개합니다! 10월의 주제는 골목마다 숨어있는 특별한 한 끼! 미식가의 발걸음을 사로잡는 맛집 이야기~ 맛집 블로그 따뜻한 집밥의 향기, 누구나 쉽게 따라 할 수 있는 소소하지만 특별한 레시피 모음! 요리·레시피 블로그 길 위에서 만나는 짜릿한 순간! 드라이버가 전해주는 특별한 자동차 이야기~ 자동차 블로그 마음을 두드리는 문장의 힘, 지혜와 감성을 채워주는 책 속 특별한 이야기를 담아! 문.......	["https://blogthumb.pstatic.net/MjAyNTA5MjRfMTEz/MDAxNzU4Njk4OTI2MDIy.9tAWoQ8dXNy9jyEiNEFIcC2pYAU3UtDp9e7v8qjIxEEg.P13mNfn537gJpmYiehGhbPr2_HYd8In7ow4tHcj1BHAg.PNG/%BC%D2%B0%B3_10.png?type=s3"]	https://blog.naver.com/blogpeople/224040569656?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
492d2627b437d498	[2025 블로그 챌린지] 보너스 퀘스트 4차 결산 ⚾️⚽️ (마지막 공지!)	안녕하세요, 네이버 블로그팀입니다! 밝아온 2026년, 새해의 첫 한 주가 벌써 지났습니다! 블로거 여려분들은 새해를 잘 보내고 계시나요? 오늘은 2025 블로그 챌린지의 마지막 공지로 돌아왔는데요. 4번째 보너스 퀘스트에서 블챌러들이 가장 많이 첨부한 스포츠 글감 TOP 10은 과연 무엇일지 정리했습니다! 지금 같이 확인해보시죠! GO GO! 도파민 충전 퀘스트 TOP 10 스포츠 글감 부문 1위 한화 이글스 ⚾️ 2위 KIA 타이거즈 ⚾️ 3위 삼성 라이온즈 ⚾️ 4위 롯데 자이언츠 ⚾️ 5위 LG 트윈스 ⚾️ 6위 두산 베어스 ⚾️ 7위 LA FC ⚽️ 8위 흥국생명 핑크스파이더스 9위 SSG 랜더스 ⚾️ 10위 정관장 레드스파크스 ?.......	["https://blogthumb.pstatic.net/MjAyNjAxMDdfMjEx/MDAxNzY3NzUzNTU2NTU0.C4o7mnFtA_mq-CLsOd43W5rinW17g1zpiXxq_GcEn2Ig.aMGaHnzFMtryajKVxj59FI7hlTcNiJoWdyDgKUqrrZQg.PNG/%B0%F8%C1%F6_%BD%C2%BA%CE%C0%C7%BD%C3%B0%A3%B0%E1%BB%EA_1.png?type=s3"]	https://blog.naver.com/blogpeople/224137558412?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2026"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
d40131e56c5531e8	[당첨 공지] 2025 왓츠인마이블로그 챌린지 마지막 당첨자를 발표합니다	안녕하세요, 네이버 블로그팀입니다! 올가을 힘차게 시작한 2025 블로그 챌린지가 오들오들 추운 겨울에 드디어 마무리가 되었습니다 ⛄ 16주라는 긴 기간 동안 함께해 주신 모든 분들께 깊은 감사의 말씀 드립니다! ❗블챌이 종료된 바로 다음 날인 지난주 월요일❗ 마지막 OGQ 스티커를 지급해 드렸습니다! 모두 잘 받으셨나요?? 앞으로 구냥이와 함께 더더 알찬 기록들을 블로그에 남기시길 응원하겠습니다 ㅎㅎㅎ >> 대망의 오늘	["https://blogthumb.pstatic.net/MjAyNTEyMzBfMjg4/MDAxNzY3MDc2MTk1OTYz.mnGVWrfcXu2W95TGIIk8k1CZ9YUdTRKEvN5X1R1qA3Eg.Gxm9J2OT5Vy9QsxWM84Hct2jesY6fr9zlSQ9npztLh0g.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224127926587?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
73864e3dd8769281	1월, 이달의 블로그를 추천해 주세요!	2026년 1월의 주제는 사진, IT·컴퓨터, 만화·애니, 패션·미용 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1. 본인.......	["https://blogthumb.pstatic.net/MjAyNTEyMDVfMTI0/MDAxNzY0OTIwMDczNjg2.K6m-5e5QnmJEsbv3T-USkqeySiLF4mC5E-coeEC-u-sg.NumvVeMQh7s0xiN-esp3Xues2vkD9eWk-3lVhexyRuMg.PNG/%C3%DF%C3%B5_01_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224126781280?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
7cd50101ca4e151d	특별한 연말 리추얼! 2025 마이 블로그 취향 리포트 확인해 보셨나요? (ft.인생네컷 프레임 깜짝 공개)	안녕하세요, 블로그팀입니다. 2025년 마이 블로그 리포트는 블로그를 통해 보는 나의 취향 리포트라는 컨셉으로 준비해 보았는데요, 다들 확인해 보셨을까요? 대표 섬네일을 보시면 컬러부터 계절까지 블로거 분들의 데이터에 따라 다르게 녹여진 섬네일이 생성되는데요. 각양각색 모두 다른 대표 섬네일을 살펴보는 재미가 있더라고요. 아직 나의 섬네일을 확인하기 전이라면 아래 링크로 방문하여 내 취향 리포트 보기와 내 블로그에 발행을 해보세요! 취향 리포트 참여 혜택으로 가장 야심 차게 준비한 상품! 블로그 X 인생네컷 스페셜 프레임 촬영권을 준비하였는데요, 넉넉하게 6,000장을 준비했으나 눈 깜짝할 사이 마감되었다는 사실! 여.......	["https://blogthumb.pstatic.net/MjAyNTEyMjNfMjE1/MDAxNzY2NDgyNjM0NDUy.ny20PguSNkKenWpqlfvsq-8CYjcMhEsRABajUw_GMugg.9Dz1soIrTfEdpqd6Vv14lFDIzZfTG3QR08hr63S0yt4g.PNG/%B8%B6%BA%ED%B8%AE_%B0%F8%C1%F601.png?type=s3"]	https://blog.naver.com/blogpeople/224120202836?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
f66b67d1a70f8d6b	[당첨 안내][2025 블로그 리포트] 드디어 돌아온 블로그 연말 결산 취향 분석 리포트가 도착했습니다	[1/20(화) 네이버페이 포인트 & 블로그 굿즈 당첨 안내] 1/20(화) 오후 중 2025 마이 블로그 리포트 이벤트 당첨자 분들께 네이버페이 포인트 지급이 완료되었습니다! 또한, 블로그 굿즈 당첨자 분들께 메일로 당첨 정보 기입 안내를 드렸습니다. ~1/27(화) 까지 확인 부탁드립니다. 당첨되신 분들 모두모두 축하드립니다. :) 안녕하세요, 네이버 블로그팀입니다. 어느새 2025년을 마무리하는 12월입니다. 올 한 해, 여러분의 일상은 어떤 순간들로 채워졌나요? 다정하고 즐거운 순간들로 가득했길 바라봅니다. 연말 하면 블로그 리포트가 빠질 수 없는데요! 2025년도 블로그와 함께해 주신 여러분들을 위해 블로그 연말 리포트가 더욱 풍성.......	["https://blogthumb.pstatic.net/MjAyNTEyMTlfNSAg/MDAxNzY2MTQ2ODE0NTYx.Qa2t7Bv03zzvGtyQd4r-2kdoXw_xYvCoRCiZ5fyEqwog.xegaQ8wr6Nmijt2wvChu93mzNvFV1cumBCoD4rMvaFwg.PNG/%BA%ED%B7%CE%B1%D7%B8%AE%C6%F7%C6%AE_%B0%F8%C1%F601.png?type=s3"]	https://blog.naver.com/blogpeople/224115868851?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
ad1b46fe2b3f0876	2025 블챌 마무리! <같이 보는 블챌러들의 왓츠인마이블로그> 3편	안녕하세요! 네이버 블로그팀입니다. 어느덧 종료까지 단 3일만을 남겨두고 있는 왓츠인마이블로그 챌린지! 다들 완주를 향해 꾸준히 달려가고 계신가요~? 블챌 담당자들은 챌린지 완주까지 과연 몇 분이 성공하실지 마음을 졸이며 바라보고 있답니다! 오늘은 마지막으로 블로그 챌린지에 참여중인 요즘 핫한 블챌러 들을 소개해 드리고자합니다! 2025 왓츠인마이블로그 챌린지와 함께한 요즘 핫한 블챌러 지금 소개합니다! 소개해 드리는 블로거분들 중 나와 취향이 꼭 맞는 분은 이웃 추가를 잊지 말아 주세요 명실상부 2025년 가장 웃긴 블로거 1위 추천! 후루꾸님의 블챌글 [요즘 본 영화] 나우 유 씨 미 3 .......	["https://blogthumb.pstatic.net/MjAyNTEyMTlfMjIy/MDAxNzY2MTA2OTA4MTYz.r-EGvBdmDSdkffEbRbJowfsDeAO1SXqeZMhrp8LN_pkg.GUm95ksNVDJlsFKc5zbXxdqTgtbOYA5M3kB9N4EKUogg.PNG/%C3%A7%B8%B0%C1%F6%B0%F8%C1%F6_01_%C4%BF%B9%F6_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224115150189?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
bdba8345c2bc0909	[올해의 블로그] 2025년을 빛낸 올해의 블로그를 소개합니다.	안녕하세요, 네이버 블로그팀입니다! 어느덧 한 해의 마지막 겨울 추위가 본격 다가온 2025년의 12월. 블로거 여러분들은 올 한 해 마무리를 어떻게 하고 계신지 궁금한 나날인데요! 오늘은 특별히 2025년도를 빛낸 100분의 블로그를 소개해 드리기 위해 찾아왔습니다. 올해 벌써 3년 차를 맞은 올해의 블로그 100, 2025년에는 어떤 분들이 올해의 블로그로 선정되셨을지, 지금 바로 소개해 드리겠습니다. 2025 올해의 블로그 '올해의 블로그'는 한 해 동안 다양한 주제에서 유익한 정보를 공유하고, 나만의 생각과 경험을 기록하며 활발하게 활동한 그 해의 대표 블로그에게 드리는 특별한 이름입니다. 한 해 동안 선정된 이달의 블로.......	["https://blogthumb.pstatic.net/MjAyNTEyMDhfMTg5/MDAxNzY1MTg1MDE0NjI4.SwC0vkvbVAJsnvZSYGhMK9pi1MAyJpdLQNOZUBJ4MOMg.U5Sxly8tVhAZv4iELAEiK15RepqxacOK95WSNmdL5JEg.PNG/Teamblog_01_v2.png?type=s3"]	https://blog.naver.com/blogpeople/224102511263?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
69471880941c0990	이달의 블로그 연말결산, 2025년도 고마웠어요!	안녕하세요, 네이버 블로그팀입니다! 쉼 없이 달려온 2025년, 블로그팀의 변화와 새로운 도전으로 가득했던 한 해도 저물어가고 있습니다! 블로거 여러분들도 올 겨울을 따뜻하고 편안하게 맞이하고 계신가요? 2025년에도 블로그가 지식과 노하우, 그리고 소중한 일상을 나누는 곳으로 빛날 수 있었던 것은 모든 블로거분들의 적극적인 참여 덕분이었습니다. 특히, 이달의 블로거분들께서 블로그에 남겨주신 다양한 양질의 글들과 진정성 있는 소통은 블로그 생태계에 큰 활력을 불어넣어 주셨습니다! 2025년 올 연말에도 감사의 마음을 담아 이달의 블로그분들께 드릴 블로그 굿즈 패키지를 정성껏 준비했습니다. 그 전에 잠시, 올해 새로운 기.......	["https://blogthumb.pstatic.net/MjAyNTEyMDVfMjAx/MDAxNzY0OTEzMTcxNzYy.Fqhc6V0uIsLbATcQIzlQWtTD9072_st92T4jSUE7fyYg.NJ-bW2JKLKLM3eeOB_PWj8il0dmNwDeXW1riYybkNsAg.JPEG/1.%B0%F8%C1%F6__%BD%E6%B3%D7%C0%CF.jpg?type=s3"]	https://blog.naver.com/blogpeople/224099250534?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
56863345c5c02495	[당첨 공지] 2025 왓츠인마이블로그 챌린지 3차 당첨자를 발표합니다	안녕하세요, 네이버 블로그팀입니다! 지난 2회의 블로그 챌린지 당첨자 발표로 약 9만 명의 블로거분들이 다양한 혜택들을 받아 가셨는데요..! 역대급 혜택으로 가득한 2025 블로그 챌린지 잘 참여하고 계시나요? 지난주 귀염뽀짝한 [마이블로그모음ZIP] 스티커를 지급해 드렸습니다!! 블로그와 찰떡인 곰돌이군과 함께 ❗ 아주 열심히❗ 챌린지에 참여해 주고 계실 것이라 생각합니다 ㅎㅎ 드디어 오늘 2025 블로그 챌린지 3차 당첨자 발표가 진행되는데요! 행운의 당첨자는 과연 누구일지 지금 바로 공개합니다 ⬇️⬇️⬇️ 첫 번째, 9주 차부터 12주 차까지 한 주차에라도 챌린지 글을 작성하면 받을 수 있는 주차별 참여 혜택!! 총 4만 명의.......	["https://blogthumb.pstatic.net/MjAyNTEyMDRfMjg4/MDAxNzY0ODQwODc3NzQ2.mrAkA7EgISLTyEma7tgm4iPvlOkmaw-_3-RGO3qAWH0g.YE34QntAo3dAXjgSBrcPjAe0bEqYGPYgbtL8ugWYeO8g.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224098325073?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
5a4d981c2a5ddb17	MY플레이스에서 영수증 인증하고 블로그 내돈내산 글 작성해 보세요!	안녕하세요! 네이버 블로그팀입니다. '왓츠인 마이 블로그' 챌린지가 가열차게 진행 중인 요즘, 내돈내산 컴포넌트를 첨부하여 챌린지에 참여하신 적이 있으실까요? 챌린지 덕분에 이웃분들의 '찐' 내돈내산 글들도 여기저기서 반갑게 더 많이 만나볼 수 있는 요즘인데요, 드디어, 내돈내산 방문 탭에 '영수증 인증' 내역이 추가됩니다. 내돈내산 방문 인증 내역 AS-IS : 네이버 예약, 네이버 주문 이용 완료 내역 TO-BE : 네이버 예약, 네이버 주문 이용 완료 내역, MY플레이스 영수증 인증 ※ 1년 이내 인증된 내역만 첨부 가능합니다. 그동안 예약, 주문 기능이 없는 장소의 경우, 블로그 내돈내산 글을 남길 수.......	["https://blogthumb.pstatic.net/MjAyNTEyMDNfMjkw/MDAxNzY0NzM3NTkwMDQ2.aG4zr5Gcwa3Yk8UkRJ95MprO7xpmsyX3IFSZOLV54W8g.GUzYte6ljcnEkYP0c_3-FFqzhWIBN-a07KtaCF4k11Ig.PNG/%B3%BB%B5%B7%B3%BB%BB%EA%B0%F8%C1%F6_01.png?type=s3"]	https://blog.naver.com/blogpeople/224096822166?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
89f6175b4a0439e7	12월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 단풍이 떨어지고 벌써 한 해의 마지막을 향해 가네요. 다들 추운 날씨 감기 조심하세요! 그럼, 이웃님들과 함께 하면 좋을 2025년 12월 이달의 블로그를 소개합니다! 12월의 주제는 클래식부터 K-POP까지 다양한 장르의 음악을 소개해 드릴게요! 음악 블로그 워킹맘, 육아 대디가 들려주는 우리 아이 육아꿀팁의 모든 것! 육아·결혼 블로그 전문가에게 배우는 찐교육! 교실 안부터 교실 밖 이야기 담았어요~ 교육·학문 블로그 내 꿈은 세계여행 일주! 여권과 가방만 있으면 어디든 갈 수 있어~ 세계여행 블로그 좋아하는 취미를 매일 기록해요. 낚시부터 와인까지 취미 부자 일기 엿보기! 취미 블로그 이달의.......	["https://blogthumb.pstatic.net/MjAyNTExMjRfNzAg/MDAxNzYzOTcwODUwMDE3.nmnigmM6E3d8O4Uw_zeTaFltkiPiYM0aHBuv8FNiD4Mg.XP2Cg0dFjF17V92PHiK9cPZbI76-QpXWsChljOulL6Mg.PNG/%BC%D2%B0%B3_12.png?type=s3"]	https://blog.naver.com/blogpeople/224095603548?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
78ae59beeb33c6ca	[2025 블로그 챌린지] 보너스 퀘스트 3차 결산	안녕하세요, 네이버 블로그팀입니다! 벌써 2025 블로그 챌린지의 세번째 보너스 퀘스트, 도파민 충전 퀘스트가 11/23(일)자로 마무리 되었습니다!! 과연, 블로거들은 어떤 컨텐츠에서 도파민을 충전하고 있었는지 담당자인 저희도 무척 궁금한데요! 지난 한달간 블로거들이 가장 많이 첨부한 방송, 영화, 책 글감 TOP 10 지금 바로 확인하시죠! 도파민 충전 퀘스트 TOP 10 방송 글감 부문 1위 나는 SOLO 2위 신인감독 김연경 3위 서울 자가에 대기업 다니는 김부장 이야기 4위 콩콩팡팡 5위 태풍상사 6위 우주메리미 7위 키스는 괜히 해서! 8위 환승연애 9위 모범택시3 10위 이강에는 달이 흐른다 연애.......	["https://blogthumb.pstatic.net/MjAyNTExMjhfMjU4/MDAxNzY0MzIxMzcxNDgx.YdXE8He7oleVO0C_HHLpbrH5_v4PjMgGmHQMbrV9D5og.sX5Qva8qpCwTGjyfzIVJCRkkAWG1TKcWeAWCDvSuShgg.PNG/%B0%F8%C1%F6_%B5%B5%C6%C4%B9%CE%B0%E1%BB%EA_1.png?type=s3"]	https://blog.naver.com/blogpeople/224091454924?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
9715047f33e62616	2025 블로그 챌린지 승부의 시간 퀘스트 오픈! 내 심장을 뛰게 한 스포츠 팀 ️❤️‍	안녕하세요, 네이버 블로그팀입니다. 무려 16주간의 2025 블로그 챌린지 대장정! 단 마지막 4주를 남겨두고 있는데요, 모두 잘 참여하고 계시나요? 13주 차의 시작과 함께 힘차게 오픈한 마지막 보너스 퀘스트를 공개합니다!! 네 번째 보너스 퀘스트 미션 글감은 바로바로 승부의 시간이 도래했음을 알려주는 ⚽ 스포츠 글감 ⚾ 입니다! 스포츠 글감은 10월 중 새롭게 추가된 신규 글감인데요 다양한 국내외 스포츠 팀 단위의 글감을 첨부하여 올해 가장 재밌었던 경기, 내 인생 경기, 요즘 응원하는 최애 팀 등의 기록들을 승부의 시간 퀘스트로 남겨보세요!! 이번 주(11/24)부터 4주간 스포츠 글감을 공략하는 승부의 시간 퀘스트 많.......	["https://blogthumb.pstatic.net/MjAyNTExMjRfNDYg/MDAxNzYzOTc2OTI5NzE2.tm-9LWWCnkzKa-DY-iKlpXk3evl48gxerYrQXQFIw6Ug.1i8069eeAwfDFPP4I_HILqjva2qe-WAEDwtzvMFvGWAg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224086632823?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
f53beeab485a4a22	12월, 이달의 블로그를 추천해 주세요!	2025년 12월의 주제는 세계여행, 취미, 음악, 교육·학문, 육아·결혼 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1.......	["https://blogthumb.pstatic.net/MjAyNTExMDZfMTUx/MDAxNzYyNDE2Mzc2Njcw.FFuA3-Vtif2e8jA-vHShnOPYwCNDRSoyhjrpfRT0NOkg.mL0-E_o_Fnnw_tyiTYhkohTgz-bwoeTFKCo6hk-hgnkg.PNG/%C3%DF%C3%B5_12_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224086116194?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
c4beb82b6d84d762	2025 블챌 중간 점검! <같이 보는 블챌러들의 왓츠인마이블로그 2편>	안녕하세요! 네이버 블로그팀입니다. 벌써 11주 차로 한창 진행 중인 왓츠인마이블로그 챌린지! 즐겁게 참여해 주시고 계시나요~? 블챌 담당자들은 여러분이 작성해 주신 다양한 글감의 챌린지 글들을 글감 피드를 넘나들며 즐겁게 읽어보고 있습니다! 블로거 여러분들도 다른 블로거들은 '왓츠인마이블로그'에 어떤 글감을 기록하고 있을까~~? 궁금하실 것 같은데요! 그래서 준비했습니다! 글감별로 모아보는 주목할 만한 블챌러 소개해 드리는 블로거분들 중 나와 취향이 꼭 맞는 분은 이웃 추가도 잊지 말아 주세요 내 이웃이 되어라! [공연·전시 글감] [방송 글감] [스포츠 글감] [영화 글감] [음악 글감] [책 글감.......	["https://blogthumb.pstatic.net/MjAyNTExMTRfMjE1/MDAxNzYzMTA4NjAzOTk3.e2dYZ-7X7VWqMjrjvfIkToTQx6_U6DuBi4sjMTBteU8g.DLdRk638qLn8RNf1Q_Nyy4ZSroeRdJYh-a4Q6NvQscYg.PNG/%C3%A7%B8%B0%C1%F6%B0%F8%C1%F6_01_%C4%BF%B9%F6.png?type=s3"]	https://blog.naver.com/blogpeople/224076112245?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
74fda1175683f527	11월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 찰나같은 가을이 지나가고, 두꺼운 외투를 꺼내야 할 계절이 왔어요. 부디 올 겨울은 따뜻하게 보내시길 바랍니다 :) 그럼, 이웃님들과 함께 하면 좋을 2025년 11월 이달의 블로그를 소개합니다! 11월의 주제는 영화의 매력은 낯선 곳으로의 여행! 장르별 주제별 다양한 영화를 소개해요~ 영화 블로그 모바일 게임, 콘솔, 보드게임까지 게임 공략이 제일 쉬웠어요! 게임 블로그 세상 모든 반려동물들을 위한 반려인이 꼭 알아야 할 꿀팁 대방출~ 반려동물 블로그 어렵고 막막한 경제 상식 쉽고 재밌게 풀어드려요! 비즈니스·경제 블로그 이달의 블로그에 선정되신 분들, 모두 축하합니다! 이달의 블로그란? 이.......	["https://blogthumb.pstatic.net/MjAyNTEwMjdfMjY2/MDAxNzYxNTUxNTMzMjYz.9bA08oMa4amzKG_VCCGwEnXeE2oTgnarrGJjn2VxxMgg.UadjrHYS2mvHLMFxdysok2Wvmgn-V7WcaVj4HYmKFzkg.PNG/%BC%D2%B0%B3_11.png?type=s3"]	https://blog.naver.com/blogpeople/224072225814?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
f13ffa2bd635b15c	[당첨 공지] 2025 왓츠인마이블로그 챌린지 2차 당첨자를 발표합니다	안녕하세요, 네이버 블로그팀입니다! 올 가을 초 힘차게 시작된 2025 블로그 챌린지가 벌써 겨울을 향해 달려가고 있는데요..! 내 블로그에 찰떡인 글감을 활용하여 챌린지에 잘 참여하고 계시나요? 드디어 지난주 많은 분들의 관심과 사랑을 받은 [블로거 눈멍냥이] 스티커를 지급해 드렸습니다! 블로그 곳곳에서 활발히 활동 중인 눈멍냥이 군을 마주치면 매우매우 흐뭇했답니다 ㅎㅎ ❗오늘은❗ 대망의 2025 블로그 챌린지 2차 당첨자 발표가 진행되는 날입니다 지난번 1차 당첨자 발표 이후 블챌 당첨 인증 글이 쏟아졌는데요..! 이번에는 더욱 많은 당첨 인원과 아주 매력적인 혜택으로 구성된 만큼, 행운의 여신이 찾아갈 2차 당첨자.......	["https://blogthumb.pstatic.net/MjAyNTExMDZfMjY4/MDAxNzYyNDEyMjc0NTU2.UoClg12leA5La5g1Fk0JBewauc3OLtL9I1b5JYTqbWUg.0mj64UgPEAja9raBrNwLiyX9lSRLoAOyqtbuVlWbprcg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224066933019?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
d1427617250253b1	25년 결산 [1~3]	(햇님맛집 입에 다 안맞는편) 누룽지오징어순대: 강릉최애음식 치킨: 거노가 걍 먹고싶다해서 삼 해벌데 추운날씨엔 뜨끈한 자쿠지지 ㅠ 감성 자쿠지 이런거아니고 찜질방ㅋㅋㅋ 이렇게 보니 감성있는거...	[]	https://blog.naver.com/hyewon4690/224286545910	혜원이의 정원	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-15 07:41:40.270957
6c24119cc4281a74	[11/24 당첨자 발표] 내가 첨부한 글감, 한눈에 확인해 보세요!	안녕하세요. 네이버 블로그팀입니다. 며칠 전 글감이 새로운 옷을 입고 업그레이드된 모습으로 돌아왔는데요. 공지 보러 가기 새로운 글감 즐겁게 사용하고 계시나요? 이제 내 블로그에 첨부했던 글감을 한눈에 모아서 볼 수 있습니다! 오늘 소개해 드리는 새로운 기능을 확인하시고, 오픈 이벤트에도 참여해 보세요 블로그 글감 블록 내 블로그 홈에 글감 블록이 새롭게 추가됩니다. 여러분의 블로그에는 어느새 차곡차곡 많은 글감이 쌓였을 것 같은데요. 내가 리뷰한 글감을 모아보면, 취향이 보인다는 점! ❤️ 따라서 취향을 적극적으로 드러내는 공간인 내 블로그 홈에 새롭게 추가하게 되었습니다. 두 가지 타입 중에.......	["https://blogthumb.pstatic.net/MjAyNTExMDVfNTgg/MDAxNzYyMzI1NDg2NjU1.2h1-VUvYEhQA7_XdOsqFleo7UXC9z07_j-jbjpXI3r0g.wWgY64Hbdrazyi42xmfMSlgp8o_5A4AH2jXhzBWLX0Yg.PNG/%BA%ED%B7%CE%B1%D7%C8%A8_%C4%BF%B9%F63.png?type=s3"]	https://blog.naver.com/blogpeople/224065740445?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
b0fd4ebb204bd1cb	[2025 블로그 챌린지] 보너스 퀘스트 2차 결산	안녕하세요, 네이버 블로그팀입니다! 올해 2025 블로그 챌린지에서는 히든 상품에 도전해 볼 수 있는 총 4회차의 보너스 퀘스트가 함께 진행되고 있는데요!! 블로거분들의 최애들을 엿볼 수 있던 덕밍아웃 퀘스트가 10/26(일) 자로 마무리되었습니다 어떤 음악, 공연·전시 글감이 요번 블챌에서 가장 핫했을지 보너스 퀘스트 2차 결산, 지금 공개합니다 ⬇️⬇️⬇️ 덕밍아웃 퀘스트 TOP 10 음악 글감 부문 1위 Blue Valentine 2위 IRIS OUT 3위 gonna love me, right? 4위 The DECADE 5위 JANE DOE 6위 COLOR OUTSIDE THE LINES 7위 Flash and Core 8위 자몽살구클럽 9위 은중과 상연 (Soundtrack from the.......	["https://blogthumb.pstatic.net/MjAyNTEwMzBfMTI4/MDAxNzYxODA0MzM1Mzc1.eXFdWocnYEUtgy84OoXIFSJV93psd1ignC88IV9uHcAg.scibOVHFW7npPz35klATBPQ1NAzrQaHTGrwNzxZuO-Qg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224058960220?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
16f7a62f0ce4ce71	11월, 이달의 블로그를 추천해 주세요!	2025년 11월의 주제는 게임, 비즈니스·경제, 영화, 반려동물 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1. 본인.......	["https://blogthumb.pstatic.net/MjAyNTEwMjlfMTk0/MDAxNzYxNzE4NDAwNjU0.uy7RYl3_8SlLZRV9NUsSt-EbQhtnvqKJj02pRPporkgg.lmEx_MKkNX5CXlti5IVVCMfy6fWuXl2tgo53WT3Zf2Mg.PNG/%C3%DF%C3%B5_11_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224057745277?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
3dc80c82efc3d236	2025 블로그 챌린지 도파민 충전 퀘스트 오픈! 내가 보고 읽은 것들을 모아봐요!	안녕하세요, 네이버 블로그팀입니다! 어느덧 2025 블로그 챌린지의 절반 시점을 지나고 있는데요! 즐겁게 챌린지에 참여하고 계시나요? 9주차 시작에 발맞춰 따끈따끈하게 오픈한 세번째 보너스 퀘스트를 여러분께 소개합니다!! 3번째 보너스 퀘스트 글감은 바로바로 여러분의 도파민을 충전해준 모든 것을 기록해 볼 수 있는 영화 책 방송 글감입니다! 이번주 (10/27)부터 4주간 영화, 책, 방송 글감을 공략하는 도파민 충전 퀘스트에 많은 참여 부탁드려요! > STEP 1 [블챌] 왓츠인마이블로그 카테고리에서 챌린지 글 작성하고, STEP 2 영화, 책 또는 방송 글감을 첨부해 주세요 STEP 3.......	["https://blogthumb.pstatic.net/MjAyNTEwMjdfMzAw/MDAxNzYxNTYxNDE3NjU1.eSxlbINxgH5dJsBv78SfDwy2bswzuVLJt459ZyBncZsg.DdtpRJ_8jnktjyhyVAQtj-FYIIe7bIzUyAWjWwAK68sg.PNG/%C3%A7%B8%B0%C1%F6%B0%F8%C1%F6_01.png?type=s3"]	https://blog.naver.com/blogpeople/224055643170?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
8f26b32ab9f4b602	[스마트에디터 ONE]  새로운 글감을 소개합니다! (+디자인도 업그레이드됐어요✨)	안녕하세요, 네이버 블로그팀입니다. 지난 7월 7일 오픈된 글감 피드와 8월 27일 개선된 글감첨부 기능 그리고 9월 1일 오픈된 왓츠인마이블로그 챌린지까지! 글감 기능은 더욱 풍성한 블로그를 위해 계속 업데이트되고 있는데요 오늘은 새롭게 추가된 글감과 (두구두구) 한층 더 업그레이드✨된 글감 디자인을 소개해 드리려고 합니다. 소식 1. 블로그에 새로운 글감이 추가됐어요 여러분, 챌린지를 오픈하며 살짝- 스포 해드린 새로운 글감 추가 소식을 기억하시나요? 그 글감은 바로바로 스포츠 글감이었습니다 ⚽️⚾️ 스포츠를 사랑하는 모든 블로거 여러분들에게 좋은 소식이 될 것 같은데요. 스포츠 팀 단위.......	["https://blogthumb.pstatic.net/MjAyNTEwMjJfNzEg/MDAxNzYxMTIzMjU3MTQ5.ozDO-OA2JnMSG-ShuolIbed_QfZ6hCHWN6P_GMmCMBog.uA1gy5TzWVNxmbAdrBHt_U7Cn3PMwfYLXTjwusId5Wkg.PNG/00.png?type=s3"]	https://blog.naver.com/blogpeople/224050169430?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
c4613e16f98f3015	[당첨 공지] 2025 왓츠인마이블로그 챌린지 1차 당첨자를 발표합니다	안녕하세요, 네이버 블로그팀입니다! 벌써 2025 블로그 챌린지의 절반이 지나가고 있는데요, 모두 열심히 참여하고 계시나요? 긴 호흡으로 진행되는 챌린지인 만큼 중간중간 여러분께 설렘을 선사해 드리고자 친구 초대 이벤트 혜택 및 첫 번째 OGQ 스티커를 지급해 드렸습니다! 블로그 서비스 곳곳에서 다양하게 활용되고 있는 밤톨이네 스티커를 만나면 아주아주 반가웠답니다 ㅎㅎ 대망의 오늘은 정말 많은 분들이 기다리고 계시는 2025 블로그 챌린지의 1차 당첨자 발표가 있는 날입니다. 빵빵한 혜택으로 모두를 놀라게 한 왓츠인마이블로그 챌린지 행운의 1차 당첨자 지금 바로 발표합니다! 첫 번째, 이번 챌린지에는 한주만 참여.......	["https://blogthumb.pstatic.net/MjAyNTEwMjJfNTcg/MDAxNzYxMDk2MjE1NTA1.DAjUHnS4OLVhKdhEyjUxarRaatMU-VPh6X66Eq_RWFwg.vZ9wRH2aXsqZNzRqAJD1TH9g4vPRWPBqY0p--ZHhBmMg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224049967473?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
1a942b8c6bb50851	[2025 블로그 챌린지] 보너스 퀘스트 1차 결산 ✈️️⛰️	안녕하세요, 네이버 블로그팀입니다! 올해 2025 왓츠인마이블로그 챌린지에서는 더블X2 혜택을 받을 수 있는 총 4회차의 보너스 퀘스트도 함께 진행되고 있는데요 블로그 챌린지의 힘찬 시작을 함께한 ✈️ 여행 마니아 퀘스트가 ✈️ 9/28(일) 자로 마무리되었습니다!! 해당 퀘스트 덕분에 정말 다양한 장소(국내, 해외) 글감을 활용한 여행기가 쌓였는데요! 어떤 장소들이 블챌에서 큰 인기를 끌었을지 보너스 퀘스트 1차 결산, ✨ 지금 공개합니다✨ ⬇️⬇️⬇️⬇️ 여행 마니아 퀘스트 TOP 10 국내장소 부문 1위 성심당 본점 2위 잠실종합운동장잠실야구장 3위 인천국제공항 제1여객터미널 4위 국립현대미술관 서울 5위 광.......	["https://blogthumb.pstatic.net/MjAyNTEwMDFfMTIy/MDAxNzU5MzA5NDcwODA0.iJWq089n14yA-EdEKUeA-r3TKENhL2ZjnZshx3D8G6Qg.11R2tKClg5tquLK8CMhBjwjPMzOSzwAZzGfvWdaVK2Yg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224028672967?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
fa1d70aaced0f390	2025 블로그 챌린지 덕밍아웃 퀘스트 오픈! 연뮤덕들 모여라!	안녕하세요, 네이버 블로그팀입니다! 2025 왓츠인마이블로그 챌린지가 오픈한 지 어느덧 한달이 지났습니다. 저희 블챌 담당자들은 글감과 함께 기록되는 챌린지 참여 글들을 정독하며 시간 가는 줄 모르는 나날들을 보내고 있었답니다! 오늘은 블로그 챌린지 혜택을 2배 챙길 수 있는 '보너스 퀘스트' 에 대해 알려드리려고 하는데요! 혹시 첫 번째 보너스 퀘스트는 바로 '여행 마니아 퀘스트'였던 것을 아시나요? 이렇게 현황판에 보너스 퀘스트 추천 글감을 넣어 작성하면 '보너스 퀘스트' 인증 뱃지가 붙어있었죠! 보너스 퀘스트는 문화의 달인 10월에도 변함없이 진행되는데요! 여러분이 즐긴 혹은 앞으로 즐.......	["https://blogthumb.pstatic.net/MjAyNTEwMDFfNDkg/MDAxNzU5MjgxMjQ2MDM0.s-lloYJXnKJzf3pBwpbAovHqs0bgZTmAHMgjAyhiCFEg.tKqkZ2vjN_KTKbYoOR3VjtRRBppeWAhHhyMKHMBGwy8g.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/224027446551?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
9828115bf5331084	10월, 이달의 블로그를 추천해 주세요!	2025년 10월의 주제는 맛집, 문학·책, 자동차, 요리·레시피 입니다. 새 글이 올라올 때마다 공감을 꾹 누르며, 즐겨보는 블로그가 있나요? 그렇다면 이번 기회에 여러분의 최애 블로그를 추천해 주세요. 추천할 때에는 꼭 아래의 네이버 폼을 이용해 주세요. [블로그 추천 예시] 네이버 블로그팀 / http://blog.naver.com/blogpeople / 항상 블로그 관련 소식을 빠르게 전달해 주는 네이버 블로그팀을 추천합니다! 잠깐 기억해 주세요! 추천해 주신 모든 분들을 소개해 드리기는 어렵습니다. 함께 나누고 싶은 좋은 블로그를 고심하고 또 고심하여 선정하겠지만, 블로그를 추천해 주실 때에는 다음의 내용을 고려해 주시면 좋겠습니다! 1. 본인의.......	["https://blogthumb.pstatic.net/MjAyNTA5MDRfOTgg/MDAxNzU2OTczNTU2NDE1.MDF1-agfVul6gf-s7EiWrvx2jhjIqOwjlpZTqjqrebQg.XPadxoG_Ynhn-d4j-QZLVmcvSFcgXj2oA1r0eKkqSd0g.PNG/%C3%DF%C3%B5_10_%281%29.png?type=s3"]	https://blog.naver.com/blogpeople/224018979759?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
4028578a598d6d05	2025 블챌 2주차, 블챌러들의 '왓츠인마이블로그' 엔 뭐가 들었나?!	안녕하세요! 네이버 블로그팀입니다. '왓츠인마이블로그' 챌린지로 나날이 재밌고 알찬 글들을 남겨주시는 요즘! 블챌 담당자들은 밤 늦게까지 여러분의 글을 읽느라 얼굴에서 미소가 떠나지 않는 나날입니다. 히히..내일 출근 해야하는데..! 블로거 여러분들도 다른 블로거들은 '왓츠인마이블로그'에 무엇을 기록하고 있을까~~? 궁금하실 것 같은데요! 그래서 저희만 보기 아까운 '왓츠인마이블로그' 로 담아주신 블챌 글들을 한아름~ 가져왔습니다! 아래 소개해 드리는 블로거 분들 중 나와 취향이 꼭 맞는 분은 이웃 추가도 잊지 말아주세요 내 이웃 최고 원래 쓰던 일상 글에 지도와 글감을.......	["https://blogthumb.pstatic.net/MjAyNTA5MTJfNjEg/MDAxNzU3NjY2ODgwNDAx.AZqSLPiQeuGg_27j8QV199KLHYUZ1X-wFADDh-4cAdMg.Rj7AuOZoD7xRHtjI37aZHH9yNJbTbFDzOcbnUKJbIpQg.PNG/%C3%A7%B8%B0%C1%F6%B0%F8%C1%F6_01_%C4%BF%B9%F6.png?type=s3"]	https://blog.naver.com/blogpeople/224005578899?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
0f76d05d32e80121	9월, 이달의 블로그를 소개합니다!	안녕하세요, 네이버 블로그팀입니다. 올해 여름은 정말 무덥고 뜨거웠던 것 같아요. 뜨거운 여름밤은 가고 하루빨리 시원한 가을을 맞이하길 바라봅니다 :) 그럼, 이웃님들과 함께 하면 좋을 2025년 9월 이달의 블로그를 소개합니다! 9월의 주제는 사람 냄새 가득한 드라마! 프로과몰입러가 리뷰하는 특별한 드라마 이야기 드라마 블로그 전문가의 인테리어 이야기부터 살림 생활 소소한 꿀팁까지 우리가 사는 家 이야기 인테리어·DIY 블로그 어쩌다 식집사! 초록초록 식물에 진심인 집사들의 텃발 일기 원예·재배 블로그 문화생활은 나의 힘! 공연 전시 예술 덕후들의 지극히 개인적인 기록 엿보기~ 공연·전시 블로그 언어 공부의 핵심은 꾸준함.......	["https://blogthumb.pstatic.net/MjAyNTA4MjVfNDAg/MDAxNzU2MTAyMDE5NTg3.U63zpziaDaYRUrlyONhKYaK_U_nlXbOgJ407ExCedYwg.0brd3RzqhlxoZZB6HSsEihgATgpcswZ_ReJno_80nu8g.PNG/%BC%D2%B0%B3_09.png?type=s3"]	https://blog.naver.com/blogpeople/224005397448?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
c041e19e14f958d1	(10/24 당첨자 발표) 새로워진 블로그앱에서 보물찾기 이벤트에 참여해보세요!	[10/24(금) 네이버페이 포인트 지급 안내] 10/24(금) 오전 중 블로그앱 보물찾기 이벤트, 행운카드 인증 이벤트 당첨자 분들께 네이버페이 포인트 지급이 완료되었습니다! 당첨되신 분들 모두모두 축하드립니다. :) 행운카드 인증 이벤트 당첨자 명단은 아래 첨부파일에서 확인해주세요! 첨부파일에서 Ctrl/Command+F 로 네이버 아이디를 검색하시면 확인 가능합니다. 꼭 알아두세요! 네이버페이 포인트는 응모한 네이버ID 로 적립됩니다. 지급 시점에 가입이 되어있지 않으면 혜택을 지급해드릴 수 없습니다. 네이버페이 가입하기> 네이버페이 포인트 보유 한도는 1인 최대 200만원으로 초과 시 대.......	["https://blogthumb.pstatic.net/MjAyNTA5MTFfOTQg/MDAxNzU3NTY1NjUxMTg5.6XjTaBaB0ctNrrFB8Qd3sSXl7JS0ptG88DG0DXEqzXQg.mHrdVKMQk6ue3jGCotXPyVOqr9f1AFN9Wx88d7_UR6sg.PNG/%BA%ED%B7%CE%B1%D7%C8%A8_1_%C4%BF%B9%F6_2_%283%29.png?type=s3"]	https://blog.naver.com/blogpeople/224003880942?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
d980f4e9d3c85ffd	새로워진 모바일 블로그 홈을 만나보세요!	안녕하세요, 네이버 블로그팀입니다. 오늘은 블로그의 새로운 얼굴! 모바일 블로그 홈의 개편 소식을 전해드리고자 합니다. 오랫동안 블로그 홈에 대한 블로거분들의 다양한 의견이 있었는데요, 이 의견들을 잘 모아 새로운 홈을 오픈하게 되었습니다!! 앞으로도 여러분의 의견에 귀 기울이며 더 좋아지는 블로그 홈이 될테니 많은 응원과 기대 부탁드립니다! 오랫동안 모바일 블로그의 첫 화면을 담당해온 이웃새글, 반가운 이웃 글이 최신 발행 순으로 보여지는 공간이었는데요. 이런 사용자 의견들이 있었습니다. 그동안 블로그팀에서 차곡차곡 모아온 여러 의견들을 담아 새로운 블로그 홈을 선보이게 되었습니다! 블로그 홈에서 새롭게.......	["https://blogthumb.pstatic.net/MjAyNTA5MjBfNzEg/MDAxNzU4MzI0MzI0MjI4.8YwKSltC-U_2ZzrrzSMLnu0G_XBnumNTPAGUKjT_ijog.FcMD-EeyBFa2PTznnh3vdJtU5ljOl6yiOkt_JN6OfpEg.PNG/%BA%ED%B7%CE%B1%D7%C8%A8_1_%C4%BF%B9%F6_11.png?type=s3"]	https://blog.naver.com/blogpeople/224003753265?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
110c56bb28152cf9	새로운 블로그, 변화를 위한 첫 번째 레터	나의 경험을 기록하는 ‘나만의 블로그’에서, 누군가에겐 발견되어 영감이 되어 주는 ‘모두의 블로그’로 블로그는 여러분과 이제 새로운 이야기를 이어가려고 합니다. 에디터 화면에서 깜빡 거리는 커서를 보며 완성된 수많은 기록들.. 에디터의 빈 화면에 글을 쓰며 때로는 즐거움을, 때로는 고독함도 느끼셨을 텐데요. 블로그는 여러분의 기록이 더 잘 발견되고 관심과 취향을 기반으로 새로운 연결을 만들고 함께 하는 즐거움이 있는 공간으로 변화를 만들어가려고 합니다. 이러한 방향성을 담아, 블로그의 새로운 브랜드 아이덴티티와 서비스 변화들을 공개합니다! New Brand Identity 기록으로 시작하는 계속되는 이야기 '|'커.......	["https://blogthumb.pstatic.net/MjAyNTA5MDVfMjI2/MDAxNzU3MDc4NDM0MjM4.GxCIj145e_3H_ia4R_2Le18aFLDDy8fpQi6U81rYPusg.jG1lpp2egavCIvJDf3xaps-uwipwhqFN8hbtXZCfFFwg.PNG/%B4%BA%BA%ED%B7%CE%B1%D7_1_%C4%BF%B9%F6.png?type=s3"]	https://blog.naver.com/blogpeople/223999413544?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
e8e6c607a5ebbb24	[담당자가 알려드림] 2025 블챌러 필독	안녕하세요! 네이버 블로그팀 2025 블챌 담당자입니다. 많은 블챌러들께서 왓츠인마이블로그 챌린지에 참여해 주시고 계신데요! 여러분들이 정성 들여 써주신 글, 챌린지에 잘 응모되도록 블챌러들께 알려드릴 필독사항 3가지 들고 왔습니다! 1. [블챌] 카테고리에 글을 썼나요? 참여하기 버튼을 눌러 생성한 파란색 [블챌] 카테고리에 글을 발행해야만 블로그 챌린지 참여로 인정됩니다. Tip!! 9월 10일(수) 이후로, 블로그 앱에서 챌린지 글을 작성할 경우, [블챌] 카테고리가 자동으로 선택되니 걱정은 덜어주세요 2. 글감을 첨부했나요? 내 글을 더 풍부하게 만들어주는 글감! 글감을 첨부하는 것이 이번 챌린지의 핵심입니다. 챌린지 참.......	["https://blogthumb.pstatic.net/MjAyNTA5MDVfMjQ0/MDAxNzU3MDU2NDYyNDk3.m4xDUq_60gv98AC6IpUbJJ2obNwXEwMwNCH8qkprv5Ag.jgIFq-X_VRxD8JttNZVj_3zOmwFMMi4YgChPaYGMMhog.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/223996569157?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
16f657f03ce02b25	블챌 오픈 2025 왓츠인마이블로그 챌린지가 시작됩니다!!	안녕하세요, 네이버 블로그팀입니다. 티저 이후로, 정말 많은 분들이 블로그 챌린지를 기다려주셨다고 들었는데요. 드디어 오늘, 2025년 블로그 챌린지가 오픈했습니다! 이전보다도 더욱 재밌고 풍성해진 왓츠인마이블로그 챌린지를 기쁜 마음으로 소개합니다! W H A T ' S I N M Y B L O G 왓츠인마이블로그? 이번 블로그 챌린지 타이틀, 꽤 친숙하지 않으신가요? 이번 블로그 챌린지는 바로 많은 블로거분들이 알고 계시는 핫한 콘텐츠, 가방 속에 무엇을 들고 다니는지 소개하는 "왓츠인마이백" 에서 시작했습니다! 왓츠인마이백처럼, 이번 챌린지에서는 내 블로그에 담길 일상, 리뷰, 여행기를 글감으로 하나하나 담아 기록해.......	["https://blogthumb.pstatic.net/MjAyNTA5MDFfMTkx/MDAxNzU2Njg4Nzk0OTIy.Qa1uErllgrup26J5vmpiu5fHFkJOxUOr5eCaZ_3RQ-Yg.O999xGrBhF-TPyE3iOMBruE9EYDNaedcUhbb7X4tOcUg.PNG/image.png?type=s3"]	https://blog.naver.com/blogpeople/223990764097?fromRss=true&trackingCode=rss	네이버 블로그 · 네이버 블로그팀 (테스트)	["강릉", "블로그", "2025"]	approved	2026-05-15 07:11:41.740121	2026-05-15 07:11:41.740121
ef7addc2f5290822	강릉 한우 맛집 명품횡성한우고집, 일상에 특별한 맛을 더하다	강릉 한우 맛집으로 입소문을 타고 있어 많이 기대하고 갔는데, 기대 이상의 경험을 하게 되어 매우... 강릉 맛집으로도 종종 언급되던 이유를 몸소 느끼게 된 순간이었습니다. 명품횡성한우고집에서 제공되는...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfODIg/MDAxNzc4ODMwMjc4ODEy.1-6hubGZHABezzEuEpGPq6zKnd4zOfkIGJK28lsphFUg.Ej3qYQirG8yV7MmOfOdo1Y4zM1TcAF1m4kSjNYTbqx8g.PNG/_ftc_disclaimer.png?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTIy/MDAxNzc4ODMwMjc5NjQx.JRMpwNWQtcY5cLlxXRm0lIiVqMlXkDhcZ-Q6RQ2nGZ4g.rZo7a077vQAwaSjJXen6V8VccS8FdX6mftabcU-m1tkg.JPEG/image_1.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTEw/MDAxNzc4ODMwMjgwNzUw.QbgWz1_7ujTkwviww2_2E8dRihMU60l0iw4QKZ4vfs4g.vHpd3vQqZw7lz5i5vNhboqjApZkovs7gez27kBOsp84g.JPEG/image_2.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjk2/MDAxNzc4ODMwMjgxODIw.KrDdmUSyfyiFvY1tfVh48d8zt14gcqeQpilK4dubPPcg.7f2mYPDQsqqqwu3n8nQFOiZgmyB_R6WKeEsx9s1iMM0g.JPEG/image_3.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTQy/MDAxNzc4ODMwMjgzMDE3.Upop0p377SXVYRLWJRWcUluG2bw-oGoCYcfd0NFVknkg.lkr837Xzev7l3iRZAMAMQU2MwZh3B5gZI8OJtMKWMb0g.JPEG/image_4.jpg?type=w800"]	https://blog.naver.com/raintip3742/224286551194	여행의 공간	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:22.979
62c4c2782b29fd41	속초 바다 호텔 숙소 위치 마리나베이 호텔 가성비	속초 바다 호텔 숙소 위치 마리나베이 호텔 가성비 강원도 여행 2일차, 강릉에서 속초로 넘어왔다.... 숙소 근처에 속초아이 외에도 청초수물회, 만석닭강정 본점등 맛집이 많아서 레알 위치깡패라고 할 수 있는데...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjgw/MDAxNzc4ODI5OTUzNDI2.lvdPg8MzOl3ZLWsT97atg-N2pQI7FahVLnRonQkmcpUg.pcKlUiAz9lGLzY20rkXYFlQCY_HctZKT7jnrO_RZ95Ug.JPEG/350.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjgw/MDAxNzc4ODI5OTUzNDg1.Rw2SwQpiSqPOIGw0WdWmsqL85V3ElW0_RMdUTMZuCm4g.vkTaGF62FG9BE4VgkQRlWz3jNgFl4xFTLtPICMfpdn8g.JPEG/353.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTkg/MDAxNzc4ODI5OTUzNjk0.oEfcczTIrucETOlh7SvslAQUx_-D_k-vuhO53fhyrBIg.41gGXa7OQHcM4SQKjQULwO2UX0ZygIC76WRzvV38Higg.JPEG/352.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNjIg/MDAxNzc4ODI5OTUzNTgw.WtQ86zKO_fhFwYBUxZBJJ4-HhKm6hTO-w8yvIvCV0SQg.2AHk75LRkvqFypivG1eOLdKrf3f9hEK8BrJdhr_3ljwg.JPEG/392.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTc0/MDAxNzc4ODI5OTUzNDY0.Kc2zkVRoHS1MnqI2PirvOadefMIB8agPp2fN-te3c0kg._Hl1wXjYIaLilJjsJ-yQU2hRsUsylEResjyg0HMWRFMg.JPEG/390.jpg?type=w800"]	https://blog.naver.com/dlditgh999/224286546336	럭키뚜래블	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:24.722
a7aba875873d37a4	김남화어머니 일상	감사합니다 #마법의검정비닐 #김남화어머니일상 #기저귀이쁘게잘싸서버려주심감사감사 #박종승 #박종승일상 #마법의검정비닐 #강릉2년차 #강릉살이중 #강릉가볼만한곳 #강릉명소 #강릉명물 #강릉맛집...	["https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTMy/MDAxNzc4ODI5NDY2Mzg0.n1xQjdO7ElRRHNXwtPBYrq_K9ZwSVgB1EwACUiaMaDEg.RR6oauVIMQF1RGMEoOyNM-K1v4nwDSeUDoCTsThcyAIg.JPEG/900_1778829010263.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMTMw/MDAxNzc4ODI4MzQ2NTM1.4SviFa2ScQg50n-dXRGA7Q8cGjyLpxfXohrfO_Z5je8g.Pajt07GVZM93xVM-Fei81yEiPhMxLt4DKeo4y98GCFsg.JPEG/900_20260515_152135.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfMjQ4/MDAxNzc4ODI4MzQ2NjQ1.4y8pKQGF5GyI_jfX5ZUdp6k94QApP9jf240mp29xIwYg.xDtyzgP_ntNF5PoQJsGGK2iBqEZRcA5lYULlYeI7Fkgg.JPEG/900_20260515_152100.jpg?type=w800", "https://mblogthumb-phinf.pstatic.net/MjAyNjA1MTVfNzkg/MDAxNzc4ODI5NDY2NDg1.miYryKGXXhveJRFfN7q5rvUoslLP-CvtCMmXcDro3csg.ZuRO3GV9oouImDaOfYpiWlhHZST8BeRx12_b1Uk4hGwg.JPEG/900_20260515_152100%280%29.jpg?type=w800"]	https://blog.naver.com/gag5630/224286536030	천하장사쏘시지	["강릉", "블로그", "2026"]	approved	2026-05-15 07:41:40.270957	2026-05-25 11:56:25.587
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.videos (id, youtube_id, title, channel_name, thumbnail_url, description, status, created_at, updated_at, embeddable, view_count, social_caption) FROM stdin;
ec018cb95cd04066	LBS9AJ2Kxt4	강릉 오면 꼭 뛰어야 하는 경포호 러닝 🏃🔥	김벅벅	https://i.ytimg.com/vi/LBS9AJ2Kxt4/maxresdefault.jpg	Day 2 in Gangneung 🏃‍♂️\n\n경포호 보면서 뛰는 아침 러닝은 못 참지.\n\n📍경포호\n\n#강릉 #경포호 #러닝 #running	approved	2026-05-15 06:56:03.402113	2026-05-15 06:56:03.402113	t	250	\N
177e1f3087b74284	F8kFEQrvqGE	#barbershop #barber #강릉바버샵 #바버워즈 #원주바버샵 #이천바버샵	Barber WARS 바버워즈 강릉점	https://i.ytimg.com/vi/F8kFEQrvqGE/maxresdefault.jpg		approved	2026-05-15 06:56:03.402113	2026-05-15 06:56:03.402113	t	0	\N
a73e9f44fdb34be8	nToSDLAbmGk	[#밥친구] 머리에 총상 입은 채 강릉에서 발견된 무장공비 11명의 시신... 자살일까 타살일까? | #이만갑 505회	채널A WORLD	https://i.ytimg.com/vi/nToSDLAbmGk/maxresdefault.jpg	#1시간순삭\n🍯몰아볼 클립 ▶ [이제 만나러 갑니다] 505회 (2021-08-23)\n\n00:00 하이라이트\n00:31 강릉에 침투한 무장공비들\n08:55 잠수함에서 발견된 편지의 정체\n15:05 무장공비 소탕 작전에 참여한 군인 등장\n18:55 ※충격※ 잠수함에서 발견된 CCTV 영상\n21:50 자살인가 타살인가? 무장공비 시신의 비밀\n31:51 유일하게 생포된 무장공비의 정체\n47:00 침투한 무장공비의 인원은?\n52:45 남은 무장공비를 잡기 위한 방법\n01:01:05 36일간 숨 막히는 추격전💥\n01:10:19 北에서 강릉 무장공비 사건을 바라보는 시선\n\n#밥친구 #이만갑 #이제만나러갑니다 \n\n채널A 이제 만나러 갑니다\n매주 일요일 저녁 8시 50분 방송\nCopyright Ⓒ 채널A. All rights reserved. 무단 전재, 재배포 및 AI학습 이용 금지	approved	2026-05-15 06:56:03.402113	2026-05-15 06:56:03.402113	t	680	\N
a7ff32ca9d6d4c41	PVXrT5FOKZw	강원도 고비밭 만나다 #여행 #강원도 #강릉 #고비 #하슬라아트월드	나비이야기	https://i.ytimg.com/vi/PVXrT5FOKZw/maxresdefault.jpg	강릉 하슬라 아트월드 뒷산에서 고비밭을 만나다	approved	2026-05-15 06:56:03.402113	2026-05-15 06:56:03.402113	t	726	\N
510f76b2bbbc4829	qHW1xRAmVPc	아르떼 뮤지엄 강릉	샹트	https://i.ytimg.com/vi/qHW1xRAmVPc/maxresdefault.jpg	아르떼 뮤지엄 대관령	approved	2026-05-15 06:56:03.402113	2026-05-15 06:56:03.402113	t	169	\N
e2f0ed04798f4354	KoDqI1c5s_E	#korea#travel#강릉#바다	Saint21c_Superman	https://i.ytimg.com/vi/KoDqI1c5s_E/maxresdefault.jpg		approved	2026-05-15 08:12:48.477687	2026-05-15 08:12:48.477687	t	2	\N
48d57277d17a4a53	RYicWbY3C70	강릉 동해바다 #여행 #동해 #바다 #하슬라아트월드 # #화단텃밭 #부부여행	나비이야기	https://i.ytimg.com/vi/RYicWbY3C70/maxresdefault.jpg		approved	2026-05-15 08:12:48.477687	2026-05-15 08:12:48.477687	t	435	\N
0a579629c22a4443	GFIKsc0ga1A	#korea#travel#강릉#바다#해당화#경포	Saint21c_Superman	https://i.ytimg.com/vi/GFIKsc0ga1A/maxresdefault.jpg		approved	2026-05-15 08:18:38.128878	2026-05-15 08:18:38.128878	t	0	\N
f9d7241e1e01440b	zxoOUqKZuA4	#korea#travel#강릉#바다#경포	Saint21c_Superman	https://i.ytimg.com/vi/zxoOUqKZuA4/maxresdefault.jpg		approved	2026-05-15 08:18:38.128878	2026-05-15 08:18:38.128878	t	2	\N
df8dc2d5355a450e	09pabDAwcI0	#korea#travel#강릉#바다#경포	Saint21c_Superman	https://i.ytimg.com/vi/09pabDAwcI0/maxresdefault.jpg		approved	2026-05-15 08:18:38.128878	2026-05-15 08:18:38.128878	t	2	\N
fa36ec3493894e79	9kldaB5RqZc	영업팀 YG 강릉 가는데 치약은 왜? #강릉 #올영  #덴티스테	고수네 / 브랜드에 행복을 더'하다	https://i.ytimg.com/vi/9kldaB5RqZc/maxresdefault.jpg		approved	2026-05-15 08:18:38.128878	2026-05-15 08:18:38.128878	t	16	\N
e8299c3f0b8d4706	yvhr5tjJ3Kw	#korea#travel#강릉#바다	Saint21c_Superman	https://i.ytimg.com/vi/yvhr5tjJ3Kw/maxresdefault.jpg		approved	2026-05-15 08:18:38.128878	2026-05-15 08:18:38.128878	t	182	\N
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: ad_alerts ad_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_alerts
    ADD CONSTRAINT ad_alerts_pkey PRIMARY KEY (id);


--
-- Name: ad_payments ad_payments_order_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_payments
    ADD CONSTRAINT ad_payments_order_id_unique UNIQUE (order_id);


--
-- Name: ad_payments ad_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_payments
    ADD CONSTRAINT ad_payments_pkey PRIMARY KEY (id);


--
-- Name: ad_performances ad_performances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_performances
    ADD CONSTRAINT ad_performances_pkey PRIMARY KEY (id);


--
-- Name: ad_pools ad_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_pools
    ADD CONSTRAINT ad_pools_pkey PRIMARY KEY (id);


--
-- Name: ad_products ad_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_products
    ADD CONSTRAINT ad_products_pkey PRIMARY KEY (id);


--
-- Name: ads ads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ads
    ADD CONSTRAINT ads_pkey PRIMARY KEY (id);


--
-- Name: auth_config auth_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_config
    ADD CONSTRAINT auth_config_pkey PRIMARY KEY (id);


--
-- Name: blog_sources blog_sources_blog_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_sources
    ADD CONSTRAINT blog_sources_blog_id_unique UNIQUE (blog_id);


--
-- Name: blog_sources blog_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blog_sources
    ADD CONSTRAINT blog_sources_pkey PRIMARY KEY (id);


--
-- Name: crawl_sources crawl_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crawl_sources
    ADD CONSTRAINT crawl_sources_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: meta_ad_insights meta_ad_insights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meta_ad_insights
    ADD CONSTRAINT meta_ad_insights_pkey PRIMARY KEY (id);


--
-- Name: meta_campaign_budgets meta_campaign_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meta_campaign_budgets
    ADD CONSTRAINT meta_campaign_budgets_pkey PRIMARY KEY (campaign_id);


--
-- Name: rotation_rules rotation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rotation_rules
    ADD CONSTRAINT rotation_rules_pkey PRIMARY KEY (id);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- Name: ad_perf_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ad_perf_uniq ON public.ad_performances USING btree (ad_id, pool_id, date, source);


--
-- Name: events_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX events_status_idx ON public.events USING btree (status);


--
-- Name: meta_ad_insights_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX meta_ad_insights_uniq ON public.meta_ad_insights USING btree (ad_id, date_start);


--
-- Name: stories_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX stories_status_idx ON public.stories USING btree (status);


--
-- Name: videos_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX videos_status_idx ON public.videos USING btree (status);


--
-- PostgreSQL database dump complete
--

\unrestrict IXf93zBuPPiuzBRkvaKgNczev2ZEdZ8Q9xfzvIg5AqD8D0w7yniW2Sa23LaG6g5

